#define N 256
#define CORES 16
