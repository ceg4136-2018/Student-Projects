#define N 512
#define CORES 16
