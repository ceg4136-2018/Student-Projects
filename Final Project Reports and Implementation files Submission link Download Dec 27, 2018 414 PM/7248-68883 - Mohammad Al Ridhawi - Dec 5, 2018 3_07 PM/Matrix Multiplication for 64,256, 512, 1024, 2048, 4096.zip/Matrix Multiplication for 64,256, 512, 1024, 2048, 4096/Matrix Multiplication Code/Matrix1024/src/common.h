#define N 1024
#define CORES 16
