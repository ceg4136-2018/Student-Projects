#define N 64
#define CORES 16
