from __future__ import print_function, division
from PIL import Image
from keras.layers import Input, Dense, Reshape, Flatten, Dropout, multiply, MaxPooling2D, Concatenate
from keras.layers import BatchNormalization, Embedding
from keras.layers.advanced_activations import LeakyReLU
from keras.layers.convolutional import Conv2D
from keras.models import Sequential, Model
from keras.optimizers import Adam

import keras
import matplotlib.pyplot as plt
import os
import numpy as np
import cv2


class CGAN(): # This class builds the CGAN model
    def __init__(self):
        # Input shape
        self.img_rows = 75
        self.img_cols = 75
        self.channels = 1
        self.img_shape = (self.img_rows, self.img_cols, self.channels)
        self.num_classes = 2
        self.latent_dim = 500

        optimizer = Adam(0.0002, 0.5)

        # Build and compile the discriminator
        self.discriminator = self.build_discriminator()
        self.discriminator.compile(loss=['binary_crossentropy'],
                                   optimizer=optimizer,
                                   metrics=['accuracy'])

        # Build the generator
        self.generator = self.build_generator()

        # The generator takes noise and the target label as input
        # and generates the corresponding digit of that label
        noise = Input(shape=(self.latent_dim,))
        label = Input(shape=(1,))
        img = self.generator([noise, label])

        # For the combined model we will only train the generator
        self.discriminator.trainable = False

        # The discriminator takes generated image as input and determines validity
        # and the label of that image
        valid = self.discriminator([img, label])

        # The combined model  (stacked generator and discriminator)
        # Trains generator to fool discriminator
        self.combined = Model([noise, label], valid)
        self.combined.compile(loss=['binary_crossentropy'],
            optimizer=optimizer)

    def build_generator(self):  # Function to build one generator function

        model = Sequential()  # Builds a sequential model w/ three dense layers reshaping to a 75 by 75 image

        model.add(Dense(351, input_dim=self.latent_dim))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(2812))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(11250))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(np.prod(self.img_shape), activation='tanh'))
        model.add(Reshape(self.img_shape))

        model.summary()

        noise = Input(shape=(self.latent_dim,))
        label = Input(shape=(1,), dtype='int32')
        label_embedding = Flatten()(Embedding(self.num_classes, self.latent_dim)(label))

        model_input = multiply([noise, label_embedding])
        img = model(model_input)

        return Model([noise, label], img)  # Returns a model wih noise and label as input and an image as an output

    def build_discriminator(self):  # Function to Builds the discriminator

        img = Input(shape=self.img_shape)
        label = Input(shape=(1,), dtype='int32')
        label_embedding = Flatten()(Embedding(self.num_classes, np.prod(self.img_shape))(label))
        model_input = keras.layers.Multiply()([img, label_embedding])

        x = Conv2D(filters=32, kernel_size=5, activation='relu')(model_input)  # Uses two convolutions
        x = Conv2D(filters=64, kernel_size=3, activation='relu')(x)            # to extract features.
        x = MaxPooling2D(pool_size=2)(x)
        x = Dropout(0.4)(x)
        x = Flatten()(x)

        x = Concatenate()([x, label_embedding])  # Combines labels with flattened results from convolution
        x = Dense(512, activation="relu")(x)
        x = Dropout(0.25)(x)
        x = Dense(128, activation="relu")(x)
        x = Dropout(0.25)(x)
        validity = Dense(1, activation='sigmoid')(x)  # Dense layers determine if valid image

        model = Model([img, label], validity)
        model.summary()

        return model  # Returns model with an image and label as imput and validity as output

    # Training function
    def train(self, epochs, batch_size=128, sample_interval=50):

        # Load the dataset
        X_train = []
        y_train = []

        # Combs through data and sets it up for future use resizing al images to 75x75 (Can simplify for loop)
        root_dir = 'CNNTraining/TrainCars' # Root direct change for your own!
        for dirName, subdirList, fileList in os.walk(root_dir):
            if dirName == '.DS_Store':
                continue
            for fname in fileList:
                if fname == '.DS_Store':
                    continue

                if fname.endswith('.jpg') == False:
                    os.remove(dirName + "/" + fname)
                    continue

                im = Image.open(dirName + "/" + fname)
                f, e = os.path.splitext(dirName + "/" + fname)
                imResize = im.resize((75, 75), Image.ANTIALIAS)
                imResize.save(f + '.jpg', 'JPEG', quality=90)

        for dirName, subdirList, fileList in os.walk(root_dir):
            if dirName == '.DS_Store':
                continue
            print('Found directory: %s' % dirName)
            for fname in fileList:
                if fname == '.DS_Store':
                    continue
                image = cv2.imread(dirName + "/" + fname, 0)
                assert image.shape == (75, 75)
                X_train.append(image)
                y_train.append(int(os.path.basename(dirName)))

        # Reshape into NP array
        X_train = np.array(X_train)
        y_train = np.array(y_train)

        # Configure input
        X_train = np.expand_dims(X_train, axis=3)
        y_train = y_train.reshape(-1, 1)

        # Adversarial ground truths
        valid = np.ones((batch_size, 1))
        fake = np.zeros((batch_size, 1))

        for epoch in range(epochs):

            # ---------------------
            #  Train Discriminator
            # ---------------------

            # Select a random half batch of images
            idx = np.random.randint(0, X_train.shape[0], batch_size)
            imgs, labels = X_train[idx], y_train[idx]

            #print(idx.shape)
            #print(imgs.shape)

            # Sample noise as generator input
            noise = np.random.normal(0, 1, (batch_size, 500))

            # Generate a half batch of new images
            gen_imgs = self.generator.predict([noise, labels])

            # Train the discriminator
            d_loss_real = self.discriminator.train_on_batch([imgs, labels], valid)
            d_loss_fake = self.discriminator.train_on_batch([gen_imgs, labels], fake)
            d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

            # ---------------------
            #  Train Generator
            # ---------------------

            # Condition on labels
            sampled_labels = np.random.randint(0, 2, batch_size).reshape(-1, 1)

            # Train the generator
            g_loss = self.combined.train_on_batch([noise, sampled_labels], valid)

            # Plot the progress
            print("%d [D loss: %f, acc.: %.2f%%] [G loss: %f]" % (epoch, d_loss[0], 100*d_loss[1], g_loss))

            # If at save interval => save generated image samples
            if epoch % sample_interval == 0:
                self.sample_images(epoch)

    # Function that generates samples during training
    def sample_images(self, epoch):
        r, c = 2, 5
        noise = np.random.normal(0, 1, (r * c, 500))
        sampled_labels = np.random.randint(0, 2, 128).reshape(-1, 1)  # 128 = batch size

        gen_imgs = self.generator.predict([noise, sampled_labels])  # Try to generate some images

        # Rescale images 0 - 1
        gen_imgs = 0.5 * gen_imgs + 0.5

        fig, axs = plt.subplots(r, c)
        cnt = 0
        for i in range(r):
            for j in range(c):
                axs[i,j].imshow(gen_imgs[cnt,:,:,0], cmap='gray')
                axs[i,j].set_title("Class: %d" % sampled_labels[cnt])
                axs[i,j].axis('off')
                cnt += 1
        fig.savefig("temp" + str(epoch) + ".jpg")  # Save Images
        plt.close()


if __name__ == '__main__':  # Main function that builds and trains model
    cgan = CGAN()
    cgan.train(epochs=20000, batch_size=32, sample_interval=200)