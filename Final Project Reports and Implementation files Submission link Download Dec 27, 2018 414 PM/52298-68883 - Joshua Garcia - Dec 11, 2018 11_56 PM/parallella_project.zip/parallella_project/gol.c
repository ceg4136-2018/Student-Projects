#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(){
    int const WIDTH = 6;
    int const HEIGHT = 6;
    int const CYCLES = 1000;
    int grid[HEIGHT][WIDTH];
    int temp[HEIGHT][WIDTH];

    //int row;
    //int col;
    for (int row=0; row<HEIGHT; row++) {
        for (int col=0; col<WIDTH; col++) {
            if(row == 0 || row == HEIGHT-1 || (row == 1 && col == 2) || (row == 1 && col == 3) || (row == 2 && col == 1) || (row == 2 && col == 2) || (row == 3 && col == 2) || col == 0 || col == WIDTH-1) {
                grid[row][col] = 1;
            } else {
                grid[row][col] = 0;
            }
        }
    }
    printf("Initial board:\n");
    for(int row = 0; row < WIDTH; row++){
            for(int col = 0; col < HEIGHT; col++){
                
                printf("%d", grid[row][col]);
            }
            printf("\n");
    }
    printf("\n");

    //int i;
    //int x;
    //int y;
    //int neighbours;

    clock_t begin = clock();

    for(int i = 0; i < CYCLES; i++){
        //neighbours = 0;
        for (int row=0; row<HEIGHT; row++) {
            for (int col=0; col<WIDTH; col++) {
                if(row == 0 || row == HEIGHT-1 || (row == 1 && col == 2) || (row == 1 && col == 3) || (row == 2 && col == 1) || (row == 2 && col == 2) || (row == 3 && col == 2) || col == 0 || col == WIDTH-1) {
                    temp[row][col] = 1;
                } else {
                    temp[row][col] = 0;
                }
            }
        }

        /*for(int row = 0; row < WIDTH; row++){
            for(int col = 0; col < HEIGHT; col++){
                
                printf("%d", temp[row][col]);
            }
            printf("\n");
        }*/

        for(int row = 1; row < HEIGHT-1; row++){
                for(int col = 1; col < WIDTH-1; col++){
                    int neighbours = 0;
                    for(int y = -1; y <= 1; y++){
                            for(int x = -1; x <= 1; x++){
                                if(x || y) {
                                    if(grid[(row + y)][(col + x)] == 1) {
                                        neighbours++;
                                    }
                                }
                            }
                        }
                        /*if(row == 1 && col == 1) {
                            //atol(neighbours);
                            //printf("Row and Col: %d %d", row, col);
                            printf(" %d\n", neighbours);
                        }*/
                        if(grid[row][col] == 1){
                            if(neighbours < 2 || neighbours > 3){
                                temp[row][col] = 0;
                            }else{
                                temp[row][col] = 1;
                            }
                        }else if(grid[row][col] == 0){
                            if(neighbours == 3){
                                temp[row][col] = 1;
                            }else{
                                temp[row][col] = 0;
                            }
                        }
                }
            }
        printf("Next steps:\n");
        for(int row = 0; row < HEIGHT; row++){
            for(int col = 0; col < WIDTH; col++){
                grid[row][col] = temp[row][col];
                printf("%d", grid[row][col]);
            }
            printf("\n");
        }
        printf("\n");
    }
    clock_t end = clock();
    double execution_time = (double) (end - begin) / CLOCKS_PER_SEC;
    double exec_time_milli = (double) execution_time * 1000;

    printf("TIME taken by CPU in seconds: ");
    printf("%f\n", execution_time);

    printf("TIME taken by CPU in milliseconds: ");
    printf("%f\n", exec_time_milli);
}