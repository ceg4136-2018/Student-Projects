import parallel

# Initializing the variables
rounds=0

#dim alive[15]
#alive = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0] #1-d shared memory array for alive cells

# Initializing the alive cells for each core
# Shared memory array buggy in epython, manual variables used instead
a0=0
a1=0
a2=0
a3=0
a4=0
a5=0
a6=0
a7=0
a8=0
a9=0
a10=0
a11=0
a12=0
a13=0
a14=0
a15=0

# Start the number of rounds
if coreid()==0:
	rounds=input("Enter the number of rounds: ")
	rounds=bcast(rounds, 0)
else:
	rounds=bcast(none,0)

# The main program a.k.a the computational kernel

i=1
while i<=rounds:
	alive_neighbors=0

	#if coreid() == 0:

	#Check all the cores, some cores excluded since they are always dead
	#Comment out on rule 4 since recently has been causing hangs
	#Some cores should be commented out if shared memory is exceeded when running

	if coreid() == 1:
		alive_neighbors = 3
		for j in [a0,a2,a4,a5,a6]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a1 == 0) and alive_neighbors == 3:
		#	a1=1
		#	a1=bcast(a1,1)
		#else:
		#	a1=bcast(none,1)
		

		#Rule 1 and rule 3
		if (a1 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a1=0
			bcast(a1,1)		



	if coreid() == 2:
		alive_neighbors = 3
		for j in [a1,a3,a5,a6,a7]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a2 == 0) and alive_neighbors == 3:
		#	a2=1
		#	a2=bcast(a1,2)
		

		#Rule 1 and rule 3
		if (a2 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a2=0
			bcast(a2,2)		



	if coreid() == 4:
		alive_neighbors = 3
		for j in [a0,a1,a5,a8,a9]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a4 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a4=0
			bcast(a4,4)		


	if coreid() == 5:
		alive_neighbors = 5
		for j in [a0,a1,a2,a4,a6,a8,a9,a10]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a5 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a5=0
			bcast(a5,5)


	if coreid() == 6:
		alive_neighbors = 0
		for j in [a1,a2,a3,a5,a7,a9,a10,a11]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a6 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a6=0
			bcast(a6,6)


	if coreid() == 7:
		alive_neighbors = 3
		for j in [a2,a3,a6,a10,a11]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a7 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a7=0
			bcast(a7,7)		
		


	if coreid() == 8:
		alive_neighbors = 3
		for j in [a4,a5,a9,a12,a13]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a8 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a8=0
			bcast(a8,8)		

		

	if coreid() == 9:
		alive_neighbors = 0
		for j in [a4,a5,a6,a8,a10,a12,a13,14]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a9 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a9=0
			bcast(a9,9)


	if coreid() == 10:
		alive_neighbors = 0
		for j in [a5,a6,a7,a9,a11,a13,a14,a15]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a10 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a10=0
			bcast(a10,10)


	if coreid() == 11:
		alive_neighbors = 3
		for j in [a6,a7,a10,a14,a15]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a11 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a11=0
			bcast(a11,11)


	if coreid() == 13:
		alive_neighbors = 3
		for j in [a8,a9,a10,a12,a14]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a13 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a13=0
			bcast(a13,13)


	if coreid() == 14:
		alive_neighbors = 3
		for j in [a9,a10,a11,a13,a15]:
			if j==1:
				alive_neighbors += 1
		
		#Rule 4
		#if (a4 == 0) and alive_neighbors == 3:
		#	a4=1
		#	a4=bcast(a4,4)
		

		#Rule 1 and rule 3
		if (a14 == 1 and alive_neighbors > 3) or alive_neighbors < 2:
			a14=0
			bcast(a14,14)		

	
	i+=1

#sync()		
# The results
if coreid()==0:
	print "0 0 0 0 0 0"
	print "0 "+a0+" "+a1+" "+a2+" "+a3+" "+"0"
	print "0 "+a4+" "+a5+" "+a6+" "+a7+" "+"0"
	print "0 "+a8+" "+a9+" "+a10+" "+a11+" "+"0"
	print "0 "+a12+" "+a13+" "+a14+" "+a15+" "+"0"
	print "0 0 0 0 0 0"
