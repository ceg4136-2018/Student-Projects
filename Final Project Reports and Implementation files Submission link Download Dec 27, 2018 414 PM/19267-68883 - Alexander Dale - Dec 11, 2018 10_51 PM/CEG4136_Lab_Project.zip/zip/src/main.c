/*
 * Mandelbrot Programs
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "config.h"
#include "dispatcher.h"
#include "image.h"
#include "mandelbrot.h"
#include "parameter.h"

static void init_rng(void)
{
    srand(time(NULL));
}

static void print_complex(complex_t const *c)
{
    if (!c) return;
    printf("(%f, %f)\n", c->real, c->img);
}

void test_fractal_function(void)
{
    complex_t z, c;
    uint32_t i;

    c.real = -0.6;
    c.img = 0.6;
    printf("c = ");
    print_complex(&c);
    complex_zero(&z);
    printf("Z[0] = ");
    print_complex(&z);
    for (i = 0; i < 25; i++)
    {
        fractal_c(&z, 2, false, &c, &z);
        printf("Z[%u] = ", i);
        print_complex(&z);
    }
}

void test_fractal_divergence(void)
{
    complex_t c;
    uint32_t out;
    c.real = -0.6;
    c.img = 0.6;
    fractal_divergence(&c, 2, false, 32, &out);
    printf("c = ");
    print_complex(&c);
    printf("Out = %u\n", out);
}

#ifndef _NO_PNG
void test_image_exporter(void)
{
    image_t image;
    rgb_color_t color;
    uint16_t x, y;

    printf("Testing image exporter\n");
    create_image(128, 128, &image);
    for (y = 0; y < 128; y++)
    {
        for (x = 0; x < 128; x++)
        {
            color.red = (x + y) << 9;
            color.green = (127 + x - y) << 9;
            color.blue = (127 + y - x) << 9;
            image_set_color(&image, x, y, &color);
        }
    }
    export_image_to_png(&image, "sample_file.png");
    release_image(&image);
}
#endif /* _NO_PNG */

void print_image(image_t const *image)
{
    uint32_t x, y;
    printf("+-");
    for (x = 0; x < image->width; x++)
    {
        printf("--");
    }
    printf("+\n");
    for (y = 0; y < image->height; y++)
    {
        printf("| ");
        for (x = 0; x < image->width; x++)
        {
            printf((image_get_count(image, x, image->height - (y + 1)) > 0)? "  " : "X ");
        }
        printf("|\n");
    }
    printf("+-");
    for (x = 0; x < image->width; x++)
    {
        printf("--");
    }
    printf("+\n");
}

void randomize_image(image_t *image)
{
    uint32_t x, y, i, count, m;
    m = image->width * image->height * 2;
    for (i = 0; i < m; i++)
    {
        x = rand() % image->width;
        y = rand() % image->height;
        count = image_get_count(image, x, y);
        image_set_count(image, x, y, count > 0 ? 0 : 1);
    }
}

static void handle_finished_worker(worker_t *worker, image_t *image)
{
    uint32_t n_max;
    parameter_t p;
    parameter_set_t set;
    create_parameter_set(0, &set);

    worker_set_take_parameters(worker, &set);
    worker_get_n_max(worker, &n_max);
    worker_reset(worker);

    while (!parameter_set_is_empty(&set))
    {
        parameter_set_pop(&set, &p);
        image_set_count(image, p.x, p.y, p.out == n_max ? 0 : p.out);
    }
}

static void generate_pixel_set(config_t const *config, parameter_set_t *set)
{
    uint32_t x, y;
    parameter_t parameter;

    /* Initialize set */
    create_parameter_set(config->height * config->width, set);

    /* Generate the parameters for all pixels. */
    for (y = 0; y < config->height; y++)
    {
        for (x = 0; x < config->width; x++)
        {
            parameter.c.real = config->real_start + (config->scale * (float) x);
            parameter.c.img = config->img_start + (config->scale * (float) y);
            parameter.x = x;
            parameter.y = y;
            parameter_set_push(set, &parameter);
        }
    }

    if (config->shuffle)
    {
        parameter_set_shuffle(set);
    }
}

static void run_fractal(image_t *image, dispatcher_t *dispatcher, parameter_set_t *set)
{
    worker_t *worker;
    while (!parameter_set_is_empty(set))
    {
        if (!dispatcher_has_idle_worker(dispatcher))
        {
            worker = dispatcher_get_finished_worker(dispatcher, true);
            if (!worker)
            {
                fprintf(stderr, "Failed to get finished worker\n");
                exit(EXIT_FAILURE);
            }
            handle_finished_worker(worker, image);
        }
        else
        {
            worker = dispatcher_get_idle_worker(dispatcher);
            if (!worker)
            {
                fprintf(stderr, "Failed to get idle worker\n");
                exit(EXIT_FAILURE);
            }
            worker_reset(worker);
        }
        worker_set_give_parameters(worker, set);
        worker_start(worker);
    }

    while (dispatcher_has_busy_worker(dispatcher) || dispatcher_has_finished_worker(dispatcher))
    {
        worker = dispatcher_get_finished_worker(dispatcher, true);
        if (!worker)
        {
            fprintf(stderr, "Failed to get finished worker\n");
            exit(EXIT_FAILURE);
        }
        handle_finished_worker(worker, image);
    }
}

void generate_fractal(config_t const *config, image_t *image)
{
    parameter_set_t set;
    dispatcher_t *dispatcher;

    generate_pixel_set(config, &set);

    /* Initialize dispatcher */
    dispatcher = new_dispatcher();
    dispatcher_set_batch_size(dispatcher, config->batch_size);
    dispatcher_set_default_d(dispatcher, config->d);
    dispatcher_set_default_mbar(dispatcher, config->mbar);
    dispatcher_set_default_n_max(dispatcher, config->conv_threshold);

    run_fractal(image, dispatcher, &set);

    free_dispatcher(dispatcher);
    release_parameter_set(&set);
}

void color_image(config_t const *config, image_t *image)
{
    static rgb_color_t kColorPalette[] = {
        {102, 153, 255},    {51, 153, 255},
        {51, 204, 255},     {0, 255, 255},
        {102, 255, 204},    {102, 255, 153},
        {102, 255, 102},    {153, 255, 102},

        {204, 255, 102},    {255, 255, 102},
        {255, 204, 102},    {255, 153, 102},
        {255, 102, 102},    {255, 102, 153},
        {255, 102, 204},    {255, 102, 255},

        {204, 102, 255},    {153, 153, 255}
    };
    static uint32_t const kColorPaletteLength = sizeof(kColorPalette) / sizeof(rgb_color_t);
    uint32_t x, y, idx, count;
    rgb_color_t color;

    for (y = 0; y < image->height; y++)
    {
        for (x = 0; x < image->width; x++)
        {
            count = image_get_count(image, x, y);
            if (count > 0)
            {
                if (config->black_and_white)
                {
                    color.red = 255;
                    color.green = 255;
                    color.blue = 255;
                }
                else
                {
                    idx = ((count + config->color_shift) % kColorPaletteLength);
                    color.red = kColorPalette[idx].red;
                    color.green = kColorPalette[idx].green;
                    color.blue = kColorPalette[idx].blue;
                }
            }
            else
            {
                color.red = 0;
                color.green = 0;
                color.blue = 0;
            }
            image_set_color(image, x, y, &color);
        }
    }
}

int main(int argc, char **argv)
{
    config_t config;
    image_t image;

    init_rng();

    config_from_parameters(argc-1, (char const **) argv+1, &config);
    if (config.print_config)
    {
        print_config(&config);
    }

    create_image(config.width, config.height, &image);
    generate_fractal(&config, &image);

    if (config.print_fractal)
    {
        print_image(&image);
    }

    #ifndef _NO_PNG
    if (strlen(config.out_filpath) > 0)
    {
        color_image(&config, &image);
        export_image_to_png(&image, config.out_filpath);
    }
    #endif /* _NO_PNG */

    return 0;
}
