/*
 * Image and PNG
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifndef _NO_PNG
#include <arpa/inet.h>
#include <setjmp.h>
#include <png.h>
#endif /* _NO_PNG */

#include "image.h"


void create_image(uint32_t width, uint32_t height, image_t *image)
{
    uint32_t cells;
    image->width = width;
    image->height = height;
    cells = width * height;
    image->counts = (uint32_t *)malloc(cells * sizeof(uint32_t));
    if (!image->counts)
    {
        fprintf(stderr, "Failed to allocate memory for image count %u x %u\n", width, height);
        exit(EXIT_FAILURE);
    }
    image->colors = (rgb_color_t *)malloc(cells * sizeof(rgb_color_t));
    if (!image->colors)
    {
        fprintf(stderr, "Failed to allocate memory for image color %u x %u\n", width, height);
        exit(EXIT_FAILURE);
    }
    memset(image->counts, 0, cells * sizeof(uint32_t));
    memset(image->colors, 0, cells * sizeof(rgb_color_t));
}

void release_image(image_t *image)
{
    image->width = 0;
    image->height = 0;
    if (image->counts)
    {
        free(image->counts);
        image->counts = NULL;
    }
    if (image->colors)
    {
        free(image->colors);
        image->colors = NULL;
    }
}

static uint32_t get_index(image_t const *image, uint32_t x, uint32_t y)
{
    if (x >= image->width || y >= image->height)
    {
        fprintf(stderr, "Image access out of bounds: x = %u (width = %u), y = %u (height = %u)\n", x, image->width, y, image->height);
        exit(EXIT_FAILURE);
    }
    return image->width * y + x;
}

void image_set_count(image_t *image, uint32_t x, uint32_t y, uint32_t count)
{
    uint32_t idx;
    idx = get_index(image, x, y);
    image->counts[idx] = count;
}

void image_set_color(image_t *image, uint32_t x, uint32_t y, rgb_color_t const *color)
{
    uint32_t idx;
    idx = get_index(image, x, y);
    image->colors[idx].red = color->red;
    image->colors[idx].green = color->green;
    image->colors[idx].blue = color->blue;
}

uint32_t image_get_count(image_t const *image, uint32_t x, uint32_t y)
{
    uint32_t idx;
    idx = get_index(image, x, y);
    return image->counts[idx];
}

void image_get_color(image_t const *image, uint32_t x, uint32_t y, rgb_color_t *color)
{
    uint32_t idx;
    idx = get_index(image, x, y);
    color->red = image->colors[idx].red;
    color->green = image->colors[idx].green;
    color->blue = image->colors[idx].blue;
}

#ifndef _NO_PNG

#define EXPORT_EXIT(clean_up_state) exit_on_cleanup = true; goto clean_up_state

#define BIT_DEPTH 8

static uint32_t const kOneKiloByte = 1024;

static void current_time_to_png(png_time *png_time_info)
{
    time_t sys_time;
    struct tm sys_time_info;
    time(&sys_time);
    gmtime_r(&sys_time, &sys_time_info);
    png_convert_from_struct_tm(png_time_info, &sys_time_info);
}

void export_image_to_png(image_t const *image, char const *filename)
{
    FILE *out_fp;
    png_structp png_ptr;
    png_infop info_ptr;
    bool exit_on_cleanup;
    png_time cur_time;
    uint32_t x, y;
    png_byte *row_data, **rows_data;
    rgb_color_t pixel_color;
    uint8_t *red_ptr, *green_ptr, *blue_ptr;

    png_ptr = NULL;
    info_ptr = NULL;
    row_data = NULL;
    exit_on_cleanup = false;

    /*
     *  PNG and IO Setup
     */

    out_fp = fopen(filename, "wb");
    if (!out_fp)
    {
        fprintf(stderr, "Failed to open PNG export file %s\n", filename);
        EXPORT_EXIT(CLEAN_UP_END);
    }

    png_ptr = png_create_write_struct(
        PNG_LIBPNG_VER_STRING,
        NULL /* Error callback argument */,
        NULL /* Error callback function */,
        NULL /* Warning callback function */);
    if (!png_ptr)
    {
        fprintf(stderr, "Failed to create PNG structure\n");
        EXPORT_EXIT(CLEAN_UP_FILE);
    }

    info_ptr = png_create_info_struct(png_ptr);
    if (!info_ptr)
    {
        fprintf(stderr, "Failed to create PNG info structure\n");
        EXPORT_EXIT(CLEAN_UP_PNG_STRUCT);
    }

    /* PNG Meta Data */
    if (setjmp(png_jmpbuf(png_ptr)))
    {
        fprintf(stderr, "Failed to set PNG Meta Data\n");
        EXPORT_EXIT(CLEAN_UP_PNG_STRUCT);
    }

    png_init_io(png_ptr, out_fp);
    png_set_IHDR(png_ptr, info_ptr,
        image->width, image->height,
        BIT_DEPTH /* Bit Depth */,
        PNG_COLOR_TYPE_RGB /* Color Type */,
        PNG_INTERLACE_NONE /* Interlace Type */,
        PNG_COMPRESSION_TYPE_DEFAULT /* Compression Type */,
        PNG_FILTER_TYPE_DEFAULT /* Filter Type */);
    current_time_to_png(&cur_time);
    png_set_tIME(png_ptr, info_ptr, &cur_time);
    png_set_flush(png_ptr, (16 * kOneKiloByte) / (4 *image->width));
    png_write_info(png_ptr, info_ptr);

    /* PNG Image Data */
    if (setjmp(png_jmpbuf(png_ptr)))
    {
        fprintf(stderr, "Failed to set PNG Image Data\n");
        EXPORT_EXIT(CLEAN_UP_ROW_DATA);
    }

    y = 0;
    rows_data = (png_byte**)malloc(image->height * sizeof(png_byte*));
    if (!rows_data)
    {
        fprintf(stderr,
                "Failed to allocate row array data buffer (%u height, %u byte size)\n",
                image->height, (uint32_t) (image->height * sizeof(png_byte*)));
        EXPORT_EXIT(CLEAN_UP_PNG_STRUCT);
    }

    for (y = 0; y < image->height; y++)
    {
        row_data = (png_byte *)malloc(png_get_rowbytes(png_ptr, info_ptr));
        if (!row_data)
        {
            fprintf(stderr,
                    "Failed to allocate row %u data buffer (%u width, %u byte size)\n",
                    y, image->width, (uint32_t) png_get_rowbytes(png_ptr, info_ptr));
            EXPORT_EXIT(CLEAN_UP_ROW_DATA);
        }
        rows_data[y] = row_data;
        for (x = 0; x < image->width; x++)
        {
            red_ptr = (uint8_t *) &row_data[x * 3];
            green_ptr = (uint8_t *) &row_data[x * 3 + 1];
            blue_ptr = (uint8_t *) &row_data[x * 3 + 2];
            image_get_color(image, x, image->height - y - 1, &pixel_color);
            *red_ptr = pixel_color.red;
            *green_ptr = pixel_color.green;
            *blue_ptr = pixel_color.blue;
        }
    }
    png_write_image(png_ptr, rows_data);
    png_write_end(png_ptr, NULL);

CLEAN_UP_ROW_DATA:
    if (rows_data)
    {
        for (x = 0; x < y; x++)
        {
            free(rows_data[x]);
            rows_data[x] = NULL;
        }
        free(rows_data);
        rows_data = NULL;
    }
CLEAN_UP_PNG_STRUCT:
    if (png_ptr)
    {
        png_destroy_write_struct(&png_ptr, &info_ptr);
        png_ptr = NULL;
        info_ptr = NULL;
    }
CLEAN_UP_FILE:
    if (out_fp)
    {
        fclose(out_fp);
        out_fp = NULL;
    }
CLEAN_UP_END:
    if (exit_on_cleanup)
    {
        exit(EXIT_FAILURE);
    }
}

#undef EXPORT_EXIT

#endif /* _NO_PNG */
