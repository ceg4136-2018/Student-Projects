/*
 * Mandelbrot Fractal Calculator Header
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#ifndef _MANDELBROT_H_
#define _MANDELBROT_H_

#include "common.h"

/*
 *  Complex number representation
 */
typedef float real_t;
typedef struct {
    real_t real;  /* Real component */
    real_t img;   /* Imaginary component */
} complex_t;

/* Basic setters */
void complex_zero(complex_t *c);
void complex_one(complex_t *c);

/* void complex_abs(complex_t const *c, real_t *abs);  TODO: complete this. */

/*
 *  Complex number operators.
 *  Note: All input complex numbers, except complex_multi(), can be used
 *  for output too.
 */
void complex_assign(complex_t const *c, complex_t *out);
void complex_compl(complex_t const *c, complex_t *out);

void complex_add(complex_t const *a, complex_t const *b, complex_t *out);
void complex_sub(complex_t const *a, complex_t const *b, complex_t *out);

void complex_multi(complex_t const *a, complex_t const *b, complex_t *out);
void complex_power(complex_t const *base, uint32_t d, complex_t *out);


/* Fractal Equation. */
void fractal_c(
    complex_t const *z, uint32_t d, bool mbar,
    complex_t const *c, complex_t *out);

/* Sequence generator. */
void fractal_divergence(
    complex_t const *c, uint32_t d, bool mbar, uint32_t n_max, uint32_t *out);

#endif  /* _MANDELBROT_H_ */
