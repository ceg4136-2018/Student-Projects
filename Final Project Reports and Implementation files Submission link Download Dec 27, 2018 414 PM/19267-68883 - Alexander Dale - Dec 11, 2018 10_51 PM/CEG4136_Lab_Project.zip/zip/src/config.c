/*
 * Mandelbrot Program Config
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"

/*
 *  Parameters
 */
/* Integer parameters */
static char const kWidthFlag[] = "--width";
static char const kWidthName[] = "Width";
static char const kWidthDescription[] = "Width (real axis) of the fractal image in pixels";
static uint32_t const kWidthDefault = 10;
static uint32_t const kWidthMax = 32768;
static uint32_t const kWidthMin = 1;

static char const kHeightFlag[] = "--height";
static char const kHeightName[] = "Height";
static char const kHeightDescription[] = "Height (imaginary axix) of the fractal image in pixels";
static uint32_t const kHeightDefault = 10;
static uint32_t const kHeightMax = 32768;
static uint32_t const kHeightMin = 1;

static char const kExponentFlag[] = "--exponent";
static char const kExponentName[] = "Exponent";
static char const kExponentDescription[] = "Fractal exponent";
static uint32_t const kExponentDefault = 2;
static uint32_t const kExponentMax = 32;
static uint32_t const kExponentMin = 2;

static char const kBatchSizeFlag[] = "--batch-size";
static char const kBatchSizeName[] = "Batch size";
static char const kBatchSizeDescription[] = "Per-worker batch size";
static uint32_t const kBatchSizeDefault = MAX_BATCH_SIZE;
static uint32_t const kBatchSizeMax = MAX_BATCH_SIZE;
static uint32_t const kBatchSizeMin = 1;

static char const kConvergenceThresholdFlag[] = "--threshold";
static char const kConvergenceThresholdName[] = "Convergence Threshold";
static char const kConvergenceThresholdDescription[] = "Maximum sequence iteration before assuming convergence";
static uint32_t const kConvergenceThresholdDefault = 64;
static uint32_t const kConvergenceThresholdMax = 512;
static uint32_t const kConvergenceThresholdMin = 16;

static char const kColorShiftFlag[] = "--color-shift";
static char const kColorShiftName[] = "Color Shift";
static char const kColorShiftDescription[] = "A color gradient shift, used for changing the order of the gradient.  No effect if not outputing an image";
static uint32_t const kColorShiftDefault = 0;
static uint32_t const kColorShiftMin = 0;
static uint32_t const kColorShiftMax = 32;

/* Float parameters */
static char const kRealStartFlag[] = "--real-start";
static char const kRealStartName[] = "Real Start";
static char const kRealStartDescription[] = "Starting real value of the fractal";
static float const kRealStartDefault = 0.0f;

static char const kImaginaryStartFlag[] = "--img-start";
static char const kImaginaryStartName[] = "Imaginary Start";
static char const kImaginaryStartDescription[] = "Starting imaginary value of the fractal";
static float const kImaginaryStartDefault = 0.0f;

static char const kScaleFlag[] = "--scale";
static char const kScaleName[] = "Scale";
static char const kScaleDescription[] = "Pixel step size of the fractal";
static float const kScaleDefault = 0.1f;

/* Boolean parameters */
static char const kMandelbarFlag[] = "--bar";
static char const kMandelbarName[] = "Mandelbar";
static char const kMandelbarDescription[] = "Generates a Mandelbar fractal";

static char const kPrintFractalFlag[] = "--print";
static char const kPrintFractalName[] = "Print Fractal";
static char const kPrintFractalDescription[] = "Print fractal to terminal";

static char const kPrintConfigFlag[] = "--print-config";
static char const kPrintConfigName[] = "Print Config";
static char const kPrintConfigDescription[] = "Print config setup";

static char const kShufflePixelFlag[] = "--shuffle";
static char const kShufflePixelName[] = "Shuffle Pixel";
static char const kShufflePixelDescription[] = "Shuffle pixel compute order";

static char const kCenterFlag[] = "--center";
static char const kCenterName[] = "Center Start";
static char const kCenterDescription[] = "Generates fractal centered around real and imaginary start";

static char const kBlackAndWhiteFlag[] = "--bw";
static char const kBlackAndWhiteName[] = "Black and White Image";
static char const kBlackAndWhiteDescription[] = "If outputing as a PNG, then the image will be in black and white.  No effect if not outputing and image";

/* String parameters */
static char const kOutFileFlag[] = "--out";
static char const kOutFileName[] = "Output File";
static char const kOutFileDesciption[] = "PNG file for fractal to be written to";

typedef struct {
    char const *flag;
    char const *name;
    char const *description;
} flag_desc_t;

static flag_desc_t const kFlagInfo[] = {
    { "Fractal Set Parameters", "Fractal Set Parameters", "" },
    { kExponentFlag, kExponentName, kExponentDescription },
    { kMandelbarFlag, kMandelbarName, kMandelbarDescription },
    { "Fractal Parameters", "Fractal Parameters", "" },
    { kWidthFlag, kWidthName, kWidthDescription },
    { kHeightFlag, kHeightName, kHeightDescription },
    { kRealStartFlag, kRealStartName, kRealStartDescription },
    { kImaginaryStartFlag, kImaginaryStartName, kImaginaryStartDescription },
    { kCenterFlag, kCenterName, kCenterDescription },
    { kScaleFlag, kScaleName, kScaleDescription },
    { "Calculation Parameters", "Calculation Parameters", "" },
    { kConvergenceThresholdFlag, kConvergenceThresholdName, kConvergenceThresholdDescription},
    { kBatchSizeFlag, kBatchSizeName, kBatchSizeDescription },
    { kShufflePixelFlag, kShufflePixelName, kShufflePixelDescription },
    { "Output Parameters", "Output Parameters", "" },
    { kPrintFractalFlag, kPrintFractalName, kPrintFractalDescription },
    { kColorShiftFlag, kColorShiftName, kColorShiftDescription },
    { kBlackAndWhiteFlag, kBlackAndWhiteName, kBlackAndWhiteDescription },
    { kOutFileFlag, kOutFileName, kOutFileDesciption },
    { "Misc", "Misc", "" },
    { kPrintConfigFlag, kPrintConfigName, kPrintConfigDescription }
};
static uint32_t const kFlagInfoLength = sizeof(kFlagInfo) / sizeof(flag_desc_t);

static bool is_integer(char const *value)
{
    char const *ptr;
    if (!value) return false;
    for (ptr=value; *ptr; ptr++)
    {
        if (!isdigit(*ptr)) return false;
    }
    return true;
}

static bool get_integer(char const *svalue, uint32_t *value)
{
    if (!is_integer(svalue)) return false;
    return sscanf(svalue, "%u", value) == 1;
}

static void get_integer_arg_or_value(char const *name, char const *svalue, uint32_t *value)
{
    if (!get_integer(svalue, value))
    {
        fprintf(stderr, "Failed to read integer parameter %s\n", name);
        exit(EXIT_FAILURE);
    }
}

static bool try_integer_arg(char const *name, char const *arg, char const *svalue, uint32_t *value)
{
    if (strcmp(name, arg)) return false;
    if (!svalue)
    {
        fprintf(stderr, "Missing argumant for interger parameter %s\n", name);
        exit(EXIT_FAILURE);
    }
    get_integer_arg_or_value(name, svalue, value);
    return true;
}

static bool is_float(char const *value)
{
    char const *ptr;
    bool dec_point;

    if (is_integer(value)) return true;
    dec_point = false;
    for (ptr=value; *ptr; ptr++)
    {
        if (ptr == value && *ptr == '-') continue;
        if (*ptr == '.')
        {
            if (!dec_point) dec_point = true;
            else return false;
        }
        else if (!isdigit(*ptr)) return false;
    }
    return true;
}

static bool get_float(char const *svalue, float *value)
{
    if (!is_float(svalue)) return false;
    return sscanf(svalue, "%f", value) == 1;
}

static void get_float_arg_or_fail(char const *name, char const *svalue, float *value)
{
    if (!get_float(svalue, value))
    {
        fprintf(stderr, "Failed to read float parameter %s\n", name);
        exit(EXIT_FAILURE);
    }
}

static bool try_float_arg(char const *name, char const *arg, char const *svalue, float *value)
{
    if (strcmp(name, arg)) return false;
    if (!svalue)
    {
        fprintf(stderr, "Missing argumant for float parameter %s\n", name);
        exit(EXIT_FAILURE);
    }
    get_float_arg_or_fail(name, svalue, value);
    return true;
}

static bool try_bool_arg(char const *name, char const *arg, bool *value)
{
    if (strcmp(name, arg)) return false;
    *value = true;
    return true;
}

static bool try_string_arg(char const *name, char const *arg, char const *svalue, char *buf)
{
    if (strcmp(name, arg)) return false;
    strncpy(buf, svalue, CONFIG_STRING_MAX_LEN);
    return true;
}

#define CHECK_FLOAT_ARGUMENT(name, value, arg, svalue, i) \
    if (try_float_arg(name, arg, svalue, (value))) { i++; continue; }

#define CHECK_INTEGER_ARGUMENT(name, value, arg, svalue, i) \
    if (try_integer_arg(name, arg, svalue, (value))) { i++; continue; }

#define CHECK_BOOL_ARGUMENT(name, value, arg) \
    if (try_bool_arg(name, arg, value)) { continue; }

#define CHECK_STRING_ARGUMENT(name, value, arg, svalue, i) \
    if (try_string_arg(name, arg, svalue, (value))) { i++; continue; }

static void check_integer_min_max(char const *name, uint32_t *value, uint32_t min, uint32_t max)
{
    if (*value < min)
    {
        fprintf(stderr, "Warning: %s cannot be %u, setting to %u\n", name, *value, min);
        *value = min;
    }
    else if (*value > max)
    {
        fprintf(stderr, "Warning: %s cannot be greater than %u, capping\n", name, max);
        *value = max;
    }
}

bool config_from_parameters(int32_t argc, char const **argv, config_t *config)
{
    int32_t i;
    char const *arg;
    char const *svalue;
    /*Psuedo parameters */
    bool center_start;

    /*
     *  Set default values.
     */
    memset(config, 0, sizeof(config_t));
    config->width = kWidthDefault;
    config->height = kHeightDefault;
    config->d = kExponentDefault;
    config->batch_size = kBatchSizeDefault;
    config->conv_threshold = kConvergenceThresholdDefault;
    config->color_shift = kColorShiftDefault;
    config->real_start = kRealStartDefault;
    config->img_start = kImaginaryStartDefault;
    config->scale = kScaleDefault;
    config->mbar = false;
    config->print_fractal = false;
    config->print_config = false;
    config->shuffle = false;
    config->black_and_white = false;

    center_start = false;

    for (i = 0; i < argc; i++)
    {
        arg = argv[i];
        svalue = ((i + 1) < argc) ? argv[i+1] : NULL;
        if (!strcmp(arg, "--help"))
        {
            print_help();
        }

        CHECK_INTEGER_ARGUMENT(kWidthFlag, &config->width, arg, svalue, i);
        CHECK_INTEGER_ARGUMENT(kHeightFlag, &config->height, arg, svalue, i);
        CHECK_INTEGER_ARGUMENT(kExponentFlag, &config->d, arg, svalue, i);
        CHECK_INTEGER_ARGUMENT(kBatchSizeFlag, &config->batch_size, arg, svalue, i);
        CHECK_INTEGER_ARGUMENT(kConvergenceThresholdFlag, &config->conv_threshold, arg, svalue, i);
        CHECK_INTEGER_ARGUMENT(kColorShiftFlag, &config->color_shift, arg, svalue, i);

        CHECK_FLOAT_ARGUMENT(kRealStartFlag, &config->real_start, arg, svalue, i);
        CHECK_FLOAT_ARGUMENT(kImaginaryStartFlag, &config->img_start, arg, svalue, i);
        CHECK_FLOAT_ARGUMENT(kScaleFlag, &config->scale, arg, svalue, i);

        CHECK_BOOL_ARGUMENT(kMandelbarFlag, &config->mbar, arg);
        CHECK_BOOL_ARGUMENT(kPrintFractalFlag, &config->print_fractal, arg);
        CHECK_BOOL_ARGUMENT(kPrintConfigFlag, &config->print_config, arg);
        CHECK_BOOL_ARGUMENT(kShufflePixelFlag, &config->shuffle, arg);
        CHECK_BOOL_ARGUMENT(kBlackAndWhiteFlag, &config->black_and_white, arg);

        CHECK_STRING_ARGUMENT(kOutFileFlag, config->out_filpath, arg, svalue, i);

        CHECK_BOOL_ARGUMENT(kCenterFlag, &center_start, arg);

        fprintf(stderr, "Unknown argument %s\n", arg);
        exit(EXIT_FAILURE);
    }

    if (config->scale == 0.0f)
    {
        fprintf(stderr, "Warning: Scale cannot be 0.0, setting to 0.1f\n");
        config->scale = 0.1f;
    }

    check_integer_min_max(kWidthName, &config->width, kWidthMin, kWidthMax);
    check_integer_min_max(kHeightName, &config->height, kHeightMin, kHeightMax);
    check_integer_min_max(kExponentName, &config->d, kExponentMin, kExponentMax);
    check_integer_min_max(kBatchSizeName, &config->batch_size, kBatchSizeMin, kBatchSizeMax);
    check_integer_min_max(kConvergenceThresholdName, &config->conv_threshold, kConvergenceThresholdMin, kConvergenceThresholdMax);
    check_integer_min_max(kColorShiftName, &config->color_shift, kColorShiftMin, kColorShiftMax);

    if (center_start)
    {
        config->real_start -= ((config->width >> 1) * config->scale);
        config->img_start -=  ((config->height >> 1) * config->scale);
    }

    return true;
}

void print_help(void)
{
    char format_str[32];
    uint32_t longest_flag, flag_len;
    uint32_t i;
    printf("Mandelbrot Fractal Gen\n\n");

    longest_flag = 0;
    for (i = 0; i < kFlagInfoLength; i++)
    {
        flag_len = strlen(kFlagInfo[i].flag);
        if (flag_len > longest_flag)
        {
            longest_flag = flag_len;
        }
    }

    snprintf(format_str, sizeof(format_str), " %%%us %%s\n", longest_flag);

    for (i = 0; i < kFlagInfoLength; i++)
    {
        printf(format_str, kFlagInfo[i].flag, kFlagInfo[i].description);
    }

    exit(EXIT_SUCCESS);
}

void print_config(config_t const *config)
{
    printf("Config\n");
    printf("\texponent        = %u\n", config->d);
    printf("\tbar             = %s\n", config->mbar ? "true" : "false");

    printf("\twidth           = %u\n", config->width);
    printf("\theight          = %u\n", config->height);
    printf("\treal_start      = %f\n", config->real_start);
    printf("\timg_start       = %f\n", config->img_start);
    printf("\tscale           = %f\n", config->scale);

    printf("\tconv_threashold = %u\n", config->conv_threshold);
    printf("\tbatch_size      = %u\n", config->batch_size);
    printf("\tshuffle         = %s\n", config->shuffle ? "true" : "false");

    printf("\tprint_fractal   = %s\n", config->print_fractal ? "true" : "false");
    printf("\tblack_and_white = %s\n", config->black_and_white ? "true" : "false");
    printf("\tcolor_shift     = %u\n", config->color_shift);
    if (*config->out_filpath)
    {
        printf("\tout_filepath    = \"%s\"\n", config->out_filpath);
    }
    else
    {
        printf("\tout_filepath    = N/A\n");
    }

    printf("\tprint_config    = %s\n", config->print_config ? "true" : "false");
}
