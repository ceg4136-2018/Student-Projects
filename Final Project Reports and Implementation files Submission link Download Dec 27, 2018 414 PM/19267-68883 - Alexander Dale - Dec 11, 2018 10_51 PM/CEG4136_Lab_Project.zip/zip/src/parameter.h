/*
 * Mandelbrot Parameters and Results Header
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#ifndef _PARAMETER_H_
#define _PARAMETER_H_

#include "mandelbrot.h"

typedef struct {
    complex_t c;
    uint32_t x;
    uint32_t y;
    uint32_t out;
} parameter_t;

typedef struct {
    parameter_t *parameters;
    uint32_t n;
    uint32_t size;
} parameter_set_t;

void create_parameter_set(uint32_t size, parameter_set_t *set);
void release_parameter_set(parameter_set_t *set);

/* Stack operations */
void parameter_set_push(parameter_set_t *set, parameter_t const *parameter);
void parameter_set_pop(parameter_set_t *set, parameter_t *parameter);
void parameter_set_get(parameter_set_t const *set, uint32_t index, parameter_t *parameter);
void parameter_set_set(parameter_set_t *set, uint32_t index, parameter_t const *parameter);

bool parameter_set_is_empty(parameter_set_t const *set);
void parameter_set_clear(parameter_set_t *set);
void parameter_set_clear_n(parameter_set_t *set, uint32_t count);

void parameter_set_transfer(parameter_set_t *dest, parameter_set_t *src, uint32_t count);
void parameter_set_transfer_all(parameter_set_t *dest, parameter_set_t *src);

void parameter_set_shuffle(parameter_set_t *set);

#endif /* _PARAMETER_H_ */
