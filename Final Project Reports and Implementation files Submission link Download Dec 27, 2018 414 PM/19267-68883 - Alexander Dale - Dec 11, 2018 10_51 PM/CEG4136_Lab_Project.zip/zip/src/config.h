/*
 * Mandelbrot Program Config Header
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#ifndef _CONFIG_H_
#define _CONFIG_H_

#include "common.h"

#define CONFIG_STRING_MAX_LEN     255

typedef struct {
    /* Image width and height in pixels */
    uint32_t width;
    uint32_t height;
    /* Starting bottom left corner value */
    float real_start;
    float img_start;
    /* Per-pixel increment */
    float scale;
    /* Exponent */
    uint32_t d;
    /* Mandelbar mode */
    bool mbar;
    /* Batch Size */
    uint32_t batch_size;
    /* Convergence threshold */
    uint32_t conv_threshold;
    /* Print fractal */
    bool print_fractal;
    /* Print config */
    bool print_config;
    /* Shuffle pixel schedule */
    bool shuffle;
    /* Black and white image */
    bool black_and_white;
    /* Color shift */
    uint32_t color_shift;
    /* Image output file */
    char out_filpath[CONFIG_STRING_MAX_LEN+1];
} config_t;

/* Reads the program arguments and populates the config. */
bool config_from_parameters(int32_t argc, char const **argv, config_t *config);

/* Prints the program help, exiting when complete. */
void print_help(void);

void print_config(config_t const *config);

#endif /* _CONFIG_H_ */
