/*
 * Mandelbrot pthreads-Base Dispatcher
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "dispatcher.h"

#define MAX_WORKERS     16

static struct timespec const kSleepTimeMicroSeconds = {
    .tv_sec = 0,
    .tv_nsec = 1000
};

typedef enum {
    WORKER_DEAD = 0,  /* Important to be set to zero */
    WORKER_IDLE,
    WORKER_READY,
    WORKER_WORKING,
    WORKER_DONE,
    WORKER_DIE
} worker_state_t;

struct worker_st {
    /* Parameters */
    uint32_t d;
    bool mbar;
    uint32_t n_max;
    /* Dispatcher handle */
    dispatcher_t *dispatcher;
    /* Parameters */
    parameter_set_t set;
    /* State */
    worker_state_t state;
    pthread_mutex_t state_lock;
    /* Thread information */
    pthread_t thread_id;
};

struct dispatcher_st {
    /* Workers */
    worker_t workers[MAX_WORKERS];
    /* Batch Size */
    uint32_t batch_size;
    /* Default parameters */
    uint32_t default_d;
    bool default_mbar;
    uint32_t default_n_max;
};

/*
 *  Internal function
 */

static bool worker_is_alive(worker_t *worker);
static bool worker_is_dying(worker_t *worker);
static bool worker_is_working(worker_t *worker);

static void die_if_busy(worker_t *worker, char const *func_name)
{
    if (worker_is_busy(worker))
    {
        fprintf(stderr, "Worker cannot be busy when calling %s\n", func_name);
        dispatcher_kill_all(worker->dispatcher);
        exit(EXIT_FAILURE);
    }
}

static void die_if_dead(worker_t *worker, char const *func_name)
{
    if (!worker_is_alive(worker))
    {
        fprintf(stderr, "Worker is dead, cannot call %s\n", func_name);
        dispatcher_kill_all(worker->dispatcher);
        exit(EXIT_FAILURE);
    }
}

static void die_if_alive(worker_t *worker, char const *func_name)
{
    if (worker->state != WORKER_DEAD)
    {
        fprintf(stderr, "Worker is alive, cannot call %s\n", func_name);
        dispatcher_kill_all(worker->dispatcher);
        exit(EXIT_FAILURE);
    }
}

static void worker_set_state(worker_t *worker, worker_state_t state)
{
    pthread_mutex_lock(&worker->state_lock);
    worker->state = state;
    pthread_mutex_unlock(&worker->state_lock);
}

static void worker_init(worker_t *worker, dispatcher_t *dispatcher);
static void worker_kill(worker_t *worker);


static void *job_main(void *job_arg);

/*
 *  Dispatcher Methods
 */

dispatcher_t *new_dispatcher(void)
{
    dispatcher_t *dispatcher;
    uint32_t i;

    dispatcher = (dispatcher_t *)malloc(sizeof(dispatcher_t));
    if (!dispatcher)
    {
        fprintf(stderr, "Failed to allocate dispatcher\n");
        exit(EXIT_FAILURE);
    }
    memset(dispatcher, 0, sizeof(dispatcher_t));
    for (i = 0; i < MAX_WORKERS; i++)
    {
        worker_init(&dispatcher->workers[i], dispatcher);
    }
    dispatcher->batch_size = MAX_BATCH_SIZE;

    return dispatcher;
}

void free_dispatcher(dispatcher_t *dispatcher)
{
    uint32_t i;
    dispatcher_kill_all(dispatcher);
    for (i = 0; i < MAX_WORKERS; i++)
    {
        release_parameter_set(&dispatcher->workers[i].set);
    }
    memset(dispatcher, 0, sizeof(dispatcher_t));
    free(dispatcher);
}

void dispatcher_set_batch_size(dispatcher_t *dispatcher, uint32_t batch_size)
{
    if (batch_size == 0 || batch_size > MAX_BATCH_SIZE)
    {
        fprintf(stderr, "Invalid batch size (%u)\n", batch_size);
        exit(EXIT_FAILURE);
    }
    dispatcher->batch_size = batch_size;
}

void dispatcher_set_default_d(dispatcher_t *dispatcher, uint32_t d)
{
    dispatcher->default_d = d;
}

void dispatcher_set_default_mbar(dispatcher_t *dispatcher, bool mbar)
{
    dispatcher->default_mbar = mbar;
}

void dispatcher_set_default_n_max(dispatcher_t *dispatcher, uint32_t n_max)
{
    dispatcher->default_n_max = n_max;
}

bool dispatcher_has_idle_worker(dispatcher_t *dispatcher)
{
    uint32_t i;
    for (i = 0; i < MAX_WORKERS; i++)
    {
        if (worker_is_idle(&dispatcher->workers[i]))
        {
            return true;
        }
    }
    return false;
}

bool dispatcher_has_busy_worker(dispatcher_t *dispatcher)
{
    uint32_t i;
    for (i = 0; i < MAX_WORKERS; i++)
    {
        if (worker_is_busy(&dispatcher->workers[i]))
        {
            return true;
        }
    }
    return false;
}

bool dispatcher_has_finished_worker(dispatcher_t *dispatcher)
{
    uint32_t i;
    for (i = 0; i < MAX_WORKERS; i++)
    {
        if (worker_is_finished(&dispatcher->workers[i]))
        {
            return true;
        }
    }
    return false;
}

worker_t *dispatcher_get_idle_worker(dispatcher_t *dispatcher)
{
    uint32_t i;
    for (i = 0; i < MAX_WORKERS; i++)
    {
        if (worker_is_idle(&dispatcher->workers[i]))
        {
            return &dispatcher->workers[i];
        }
    }
    return NULL;
}

worker_t *dispatcher_get_finished_worker(dispatcher_t *dispatcher, bool blocking)
{
    uint32_t i;
    worker_t *worker;
    bool has_working;

    for (i = 0; i < MAX_WORKERS; i++)
    {
        worker = &dispatcher->workers[i];
        if (worker_is_finished(worker))
        {
            return worker;
        }
        if (worker_is_busy(worker))
        {
            has_working = true;
        }
    }
    /* If non-blocking, then return NULL */
    if (!blocking) return NULL;
    /* If all workers are IDLE, then there will never be a finished worker */
    if (!has_working) return NULL;

    while (true)
    {
        nanosleep(&kSleepTimeMicroSeconds, NULL);
        for (i = 0; i < MAX_WORKERS; i++)
        {
            worker = &dispatcher->workers[i];
            if (worker_is_finished(worker))
            {
                return worker;
            }
        }
    }
    return NULL;
}

void dispatcher_kill_all(dispatcher_t *dispatcher)
{
    uint32_t i;
    worker_t *worker;

    for (i = 0; i < MAX_WORKERS; i++)
    {
        worker = &dispatcher->workers[i];
        if (worker_is_alive(worker))
        {
            worker_kill(worker);
        }
    }
}

/*
 *  Worker methods.
 */

static void worker_init(worker_t *worker, dispatcher_t *dispatcher)
{
    int res;
    die_if_alive(worker, __func__);

    worker->dispatcher = dispatcher;
    create_parameter_set(MAX_BATCH_SIZE, &worker->set);
    pthread_mutex_init(&worker->state_lock, NULL);
    res = pthread_create(&worker->thread_id, NULL, job_main, worker);
    if (res != 0)
    {
        fprintf(stderr, "Failed to initialize worker thread!\n");
        dispatcher_kill_all(worker->dispatcher);
        exit(EXIT_FAILURE);
    }

    while (!worker_is_alive(worker))
    {
        nanosleep(&kSleepTimeMicroSeconds, NULL);
    }

    worker_reset(worker);
}

void worker_set_give_parameters(worker_t *worker, parameter_set_t *set)
{
    die_if_busy(worker, __func__);
    parameter_set_clear(&worker->set);
    parameter_set_transfer(&worker->set, set, worker->dispatcher->batch_size);
}

void worker_set_take_parameters(worker_t *worker, parameter_set_t *set)
{
    die_if_busy(worker, __func__);
    parameter_set_transfer_all(set, &worker->set);
}

void worker_get_d(worker_t *worker, uint32_t *d)
{
    *d = worker->d;
}

void worker_set_d(worker_t *worker, uint32_t d)
{
    die_if_busy(worker, __func__);
    worker->d = d;
}

void worker_get_mbar(worker_t *worker, bool *mbar)
{
    *mbar = worker->mbar;
}

void worker_set_mbar(worker_t *worker, bool mbar)
{
    die_if_busy(worker, __func__);
    worker->mbar = mbar;
}

void worker_get_n_max(worker_t *worker, uint32_t *n_max)
{
    *n_max = worker->n_max;
}

void worker_set_n_max(worker_t *worker, uint32_t n_max)
{
    die_if_busy(worker, __func__);
    worker->n_max = n_max;
}

void worker_start(worker_t *worker)
{
    die_if_busy(worker, __func__);
    die_if_dead(worker, __func__);

    worker_set_state(worker, WORKER_READY);
    while (!worker_is_working(worker) && !worker_is_finished(worker))
    {
        nanosleep(&kSleepTimeMicroSeconds, NULL);
    }
}

void worker_wait(worker_t *worker)
{
    while (worker_is_working(worker))
    {
        nanosleep(&kSleepTimeMicroSeconds, NULL);
    }
}

void worker_reset(worker_t *worker)
{
    dispatcher_t *dispatcher;
    die_if_busy(worker, __func__);
    die_if_dead(worker, __func__);

    /* Reset parameters */
    dispatcher = worker->dispatcher;
    worker->d = dispatcher->default_d;
    worker->mbar = dispatcher->default_mbar;
    worker->n_max = dispatcher->default_n_max;
    parameter_set_clear(&worker->set);

    if (worker_is_finished(worker))
    {
        worker_set_state(worker, WORKER_IDLE);
    }
}

static void worker_kill(worker_t *worker)
{
    if (!worker_is_alive(worker)) return;
    if (!worker_is_dying(worker))
    {
        worker_set_state(worker, WORKER_DIE);
    }
    pthread_join(worker->thread_id, NULL);
    pthread_mutex_destroy(&worker->state_lock);
}

/* State checkers */

static bool worker_is_alive(worker_t *worker)
{
    return worker->state != WORKER_DEAD;
}

bool worker_is_idle(worker_t *worker)
{
    return worker->state == WORKER_IDLE;
}

static bool worker_is_ready(worker_t *worker)
{
    return worker->state == WORKER_READY;
}

bool worker_is_busy(worker_t *worker)
{
    return worker_is_ready(worker) || worker_is_working(worker);
}

static bool worker_is_working(worker_t *worker)
{
    return worker->state == WORKER_WORKING;
}

bool worker_is_finished(worker_t *worker)
{
    return worker->state == WORKER_DONE;
}

static bool worker_is_dying(worker_t *worker)
{
    return worker->state == WORKER_DIE;
}

/*
 *  Worker Job
 */

static void *job_main(void *job_arg)
{
    uint32_t i;
    parameter_t *p;
    worker_t *worker;
    worker = (worker_t *)job_arg;
    worker_set_state(worker, WORKER_IDLE);
    while (true)
    {
        switch (worker->state)
        {
            case WORKER_READY:
                break;
            case WORKER_IDLE:
            case WORKER_DONE:
                nanosleep(&kSleepTimeMicroSeconds, NULL);
                continue;
            case WORKER_DIE:
                goto DONE_WORK_LOOP;
            default:
                fprintf(stderr, "Worker is in bad state!\n");
                goto DONE_WORK_LOOP;
        }
        worker_set_state(worker, WORKER_WORKING);
        for (i = 0; i < worker->set.n; i++)
        {
            p = &worker->set.parameters[i];
            fractal_divergence(&p->c, worker->d, worker->mbar, worker->n_max, &p->out);
        }
        worker_set_state(worker, WORKER_DONE);
    }
    DONE_WORK_LOOP:
    worker_set_state(worker, WORKER_DEAD);
    return NULL;
}
