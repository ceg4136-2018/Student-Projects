/*
 * Mandelbrot Fractal Calculator
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#include <math.h>

#include "mandelbrot.h"

/* Number Validators */
static inline bool is_infinity(real_t x)
{
    return (x == INFINITY) || (-x == INFINITY);
}

static inline bool is_valid(real_t x)
{
    return (x != NAN) && !is_infinity(x);
}

static inline bool complex_is_valid(complex_t const *c)
{
    return is_valid(c->real) && is_valid(c->img);
}

/* Math Functions */
static inline real_t absolute(real_t a)
{
    return (a < 0.0) ? -a : a;
}

/*
static real_t square_root(real_t x)
{
    real_t g;
    if (x < 0.0) return NAN;
    if (is_infinity(x)) return INFINITY;
    if (x == 0.0) return 0.0;
    g = 1.0;
    while (absolute((x / g) - g) > 0.001)
    {
        g = (g + (x / g)) / 2.0;
    }
    return g;
}*/

/*
 *  Complex number representation
 */

void complex_zero(complex_t *c)
{
    c->real = c->img = 0;
}

void complex_one(complex_t *c)
{
    c->real = 1;
    c->img = 0;
}

/* TODO: Fix error in this function.
void complex_abs(complex_t const *c, real_t *abs)
{
    *abs = square_root((c->real * c->real) + (c->img * c->img));
}*/

void complex_assign(complex_t const *c, complex_t *out)
{
    out->real = c->real;
    out->img = c->img;
}

void complex_compl(complex_t const *c, complex_t *out)
{
    out->real = c->real;
    out->img = -c->img;
}

void complex_add(complex_t const *a, complex_t const *b, complex_t *out)
{
    out->real = a->real + b->real;
    out->img = a->img + b->img;
}

void complex_sub(complex_t const *a, complex_t const *b, complex_t *out)
{
    out->real = a->real - b->real;
    out->img = a->img - b->img;
}

void complex_multi(complex_t const *a, complex_t const *b, complex_t *out)
{
    complex_t c;
    real_t temp1, temp2;
    complex_assign(a, &c);
    temp1 = c.real * b->real;
    temp2 = c.img * b->img;
    if (is_infinity(temp1) || is_infinity(temp2))
    {
        out->real = (is_infinity(temp1)) ? temp1 : -temp2;
    }
    else
    {
        out->real = temp1 - temp2;
    }

    temp1 = c.img * b->real;
    temp2 = c.real * b->img;

    if (is_infinity(temp1) || is_infinity(temp2))
    {
        out->img = (is_infinity(temp1)) ? temp1 : temp2;
    }
    else
    {
        out->img = temp1 + temp2;
    }
}

void complex_power(complex_t const *base, uint32_t d, complex_t *out)
{
    uint32_t i;
    complex_t c;

    if (d == 0)
    {
        complex_one(out);
        return;
    }

    complex_assign(base, &c);
    if (base != out)
    {
        complex_assign(base, out);
    }

    for (i = 2; i <= d; i++)
    {
        complex_multi(out, &c, out);
    }
}

/*
 *  Fractal Equations.
 */
void fractal_c(
    complex_t const *z,
    uint32_t d,
    bool mbar,
    complex_t const *c,
    complex_t *out)
{
    if (mbar)
    {
        complex_compl(z, out);
    }
    else
    {
        complex_assign(z, out);
    }
    complex_power(out, d, out);
    complex_add(out, c, out);
}

void fractal_divergence(
    complex_t const *c,
    uint32_t d,
    bool mbar,
    uint32_t n_max,
    uint32_t *out)
{
    complex_t z;
    uint32_t i;

    complex_zero(&z);
    i = 0;

    while (i < n_max && complex_is_valid(&z))
    {
        fractal_c(&z, d, mbar, c, &z);
        i++;
    }
    *out = i;
}
