/*
 * Mandelbrot Dispatcher
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#ifndef _DISPATCHER_H_
#define _DISPATCHER_H_

#include "common.h"
#include "mandelbrot.h"
#include "parameter.h"

typedef struct dispatcher_st dispatcher_t;
typedef struct worker_st worker_t;

/*
 *  Dispatcher
 *
 *  The dispatcher is a generic API for a thread pool manager.  The
 *  dispatcher must manage threads as workers and provided the
 *  worker API below.
 */

dispatcher_t *new_dispatcher(void);
void free_dispatcher(dispatcher_t *dispatcher);

/* Dispatcher Methods */
void dispatcher_set_batch_size(dispatcher_t *dispatcher, uint32_t batch_size);

/* This parameters have to do with the fractal_divergence() function. */
void dispatcher_set_default_d(dispatcher_t *dispatcher, uint32_t d);
void dispatcher_set_default_mbar(dispatcher_t *dispatcher, bool mbar);
void dispatcher_set_default_n_max(dispatcher_t *dispatcher, uint32_t n_max);

/* Worker trackers */
bool dispatcher_has_idle_worker(dispatcher_t *dispatcher);
bool dispatcher_has_busy_worker(dispatcher_t *dispatcher);
bool dispatcher_has_finished_worker(dispatcher_t *dispatcher);

worker_t *dispatcher_get_idle_worker(dispatcher_t *dispatcher);
worker_t *dispatcher_get_finished_worker(dispatcher_t *dispatcher, bool blocking);

void dispatcher_kill_all(dispatcher_t *dispatcher);

/*
 *  Worker Methods
 */

/* Parameter setters and getters */
void worker_set_give_parameters(worker_t *worker, parameter_set_t *set);
void worker_set_take_parameters(worker_t *worker, parameter_set_t *set);

void worker_get_d(worker_t *worker, uint32_t *d);
void worker_set_d(worker_t *worker, uint32_t d);

void worker_get_mbar(worker_t *worker, bool *mbar);
void worker_set_mbar(worker_t *worker, bool mbar);

void worker_get_n_max(worker_t *worker, uint32_t *n_max);
void worker_set_n_max(worker_t *worker, uint32_t n_max);

/* Worker controller */
void worker_start(worker_t *worker);
void worker_wait(worker_t *worker);
void worker_reset(worker_t *worker);

/* State checkers */
bool worker_is_idle(worker_t *worker);
bool worker_is_busy(worker_t *worker);
bool worker_is_finished(worker_t *worker);

#endif  /* _DISPATCHER_H_ */
