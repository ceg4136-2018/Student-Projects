/*
 * Common Includes
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#ifndef _COMMON_H_
#define _COMMON_H_

#include <stdint.h>
#include <stdbool.h>

#define MAX_BATCH_SIZE    512

#endif /* _COMMON_H_ */
