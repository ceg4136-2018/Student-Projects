/*
 * Mandelbrot Parallella-Base Dispatcher
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

#include <e-hal.h>

#include "dispatcher.h"
#include "e_worker.h"

#define MAX_WORKERS     16

static struct timespec const kSleepTimeMicroSeconds = {
    .tv_sec = 0,
    .tv_nsec = 1000
};

/*
 * Worker ELF file.
 * Can be redefined at compile time using -D_WORKER_ELF=<ELF path>
 */
#ifndef _WORKER_ELF
#define _WORKER_ELF     "bin/e_worker.elf"
#endif  /* _WORKER_ELF */
static char const kWorkerElfFile[] = _WORKER_ELF;

typedef struct {
    uint32_t x;
    uint32_t y;
} point_t;

struct worker_st {
    /* Parameters */
    point_t points[MAX_BATCH_SIZE];
    uint32_t param_count;
    /* Dispatcher handle */
    dispatcher_t *dispatcher;
    /* Device information */
    uint32_t dev_row;
    uint32_t dev_col;
};

struct dispatcher_st {
    /* Workers */
    worker_t workers[MAX_WORKERS];
    uint32_t worker_count;
    /* Epiphany devices */
    e_platform_t platform;
    e_epiphany_t dev;
    /* Batch Size */
    uint32_t batch_size;
    /* Default parameters */
    uint32_t default_d;
    bool default_mbar;
    uint32_t default_n_max;
};

/*
 *  Internal function
 */

static bool worker_is_alive(worker_t *worker);
static bool worker_is_dying(worker_t *worker);
static bool worker_is_working(worker_t *worker);

static void worker_init(worker_t *worker, dispatcher_t *dispatcher, uint32_t row, uint32_t col);
static void worker_kill(worker_t *worker);

static void worker_set_state(worker_t *worker, worker_state_t state);
static void worker_get_state(worker_t *worker, worker_state_t *state);
static void worker_set_to_default(worker_t * worker);
static void worker_set_param_count(worker_t *worker, uint32_t count);


static void die_if_busy(worker_t *worker, char const *func_name)
{
    if (worker_is_busy(worker))
    {
        fprintf(stderr, "Worker (%u, %u) cannot be busy when calling %s\n",
            worker->dev_row, worker->dev_col, func_name);
        dispatcher_kill_all(worker->dispatcher);
        exit(EXIT_FAILURE);
    }
}

static void die_if_dead(worker_t *worker, char const *func_name)
{
    if (!worker_is_alive(worker))
    {
        fprintf(stderr, "Worker (%u, %u) is dead, cannot call %s\n",
            worker->dev_row, worker->dev_col, func_name);
        dispatcher_kill_all(worker->dispatcher);
        exit(EXIT_FAILURE);
    }
}

/*static void die_if_alive(worker_t *worker, char const *func_name)
{
    if (worker_is_alive(worker))
    {
        fprintf(stderr, "Worker (%u, %u) is alive, cannot call %s\n",
            worker->dev_row, worker->dev_col, func_name);
        dispatcher_kill_all(worker->dispatcher);
        exit(EXIT_FAILURE);
    }
}*/

static void check_elf_exists(void)
{
    struct stat statbuf;
    if (stat(kWorkerElfFile, &statbuf) < 0)
    {
        switch (errno)
        {
            case EACCES:
                fprintf(stderr, "Cannot access worker ELF file %s\n",
                    kWorkerElfFile);
                break;
            case ELOOP:
                fprintf(stderr,
                    "Symbolic loop error while searching for worker ELF file %s\n",
                    kWorkerElfFile);
                break;
            case ENOENT:
                fprintf(stderr,
                    "Worker ELF file %s does not exist\n",
                    kWorkerElfFile);
                break;
            default:
                fprintf(stderr,
                    "Unknown error occured while searching for worker ELF file %s\n",
                    kWorkerElfFile);
        }
        exit(EXIT_FAILURE);
    }
    if (!S_ISREG(statbuf.st_mode))
    {
        fprintf(stderr, "Worker ELF file %s is not a regular file\n", kWorkerElfFile);
        exit(EXIT_FAILURE);
    }
}

static void check_platform_dimensions(e_platform_t *platform)
{
    /* Non-zero dimension */
    if (platform->cols == 0 || platform->rows == 0)
    {
        fprintf(stderr, "Platform has a zero dimension (%u, %u)\n",
            (uint32_t) platform->cols, (uint32_t) platform->rows);
        exit(EXIT_FAILURE);
    }
    /* Exact match is good, otherwise, check for alignment */
    if ((platform->rows * platform->cols) > MAX_WORKERS)
    {
        /* Check if row aligned */
        if ((platform->cols % MAX_WORKERS) == 0)
        {
            platform->rows = platform->cols / MAX_WORKERS;
        }
        else if ((platform->rows % MAX_WORKERS) == 0)
        {
            platform->cols = platform->rows / MAX_WORKERS;
        }
        else
        {
            fprintf(stderr, "Cannot align platform cores (%u, %u) with worker max %u\n",
                platform->rows, platform->cols, MAX_WORKERS);
            exit(EXIT_FAILURE);
        }
    }
    else if ((platform->rows * platform->cols) < MAX_WORKERS)
    {
        if ((platform->rows % MAX_WORKERS) != 0 || (platform->cols % MAX_WORKERS) != 0)
        {
            fprintf(stderr, "Cannot align platform cores (%u, %u) with worker max %u\n",
                platform->rows, platform->cols, MAX_WORKERS);
            exit(EXIT_FAILURE);
        }
    }
}

/*
 *  Dispatcher Methods
 */

dispatcher_t *new_dispatcher(void)
{
    dispatcher_t *dispatcher;
    worker_t *worker;
    e_platform_t *platform;
    e_epiphany_t *dev;
    uint32_t row, col, i;
    check_elf_exists();

    /* Create dispatcher. */
    dispatcher = (dispatcher_t *)malloc(sizeof(dispatcher_t));
    if (!dispatcher)
    {
        fprintf(stderr, "Failed to allocate dispatcher\n");
        exit(EXIT_FAILURE);
    }
    memset(dispatcher, 0, sizeof(dispatcher_t));

    /* Initialize platform */
    platform = &dispatcher->platform;
    dev = &dispatcher->dev;
    dispatcher->batch_size = MAX_BATCH_SIZE;
    e_init(NULL);
    e_reset_system();
    e_get_platform_info(platform);
    /* Verify platform dimensions. */
    check_platform_dimensions(platform);
    e_open(dev, 0, 0, platform->rows, platform->cols);
    /* Load program */
    e_load_group(kWorkerElfFile, dev, 0, 0, platform->rows, platform->cols, E_FALSE);

    for (row = 0, i = 0; row < platform->rows && i < MAX_WORKERS; row++)
    {
        for (col = 0; col < platform->cols && i < MAX_WORKERS; col++, i++)
        {
            worker = &dispatcher->workers[i];
            worker_init(worker, dispatcher, row, col);
            dispatcher->worker_count++;
        }
    }
    e_start_group(dev);

    return dispatcher;
}

void free_dispatcher(dispatcher_t *dispatcher)
{
    dispatcher_kill_all(dispatcher);
    e_close(&dispatcher->dev);
    e_finalize();
    memset(dispatcher, 0, sizeof(dispatcher_t));
    free(dispatcher);
}

/* Variable setters */

void dispatcher_set_batch_size(dispatcher_t *dispatcher, uint32_t batch_size)
{
    if (batch_size == 0 || batch_size > MAX_BATCH_SIZE)
    {
        fprintf(stderr, "Invalid batch size (%u)\n", batch_size);
        exit(EXIT_FAILURE);
    }
    dispatcher->batch_size = batch_size;
}

void dispatcher_set_default_d(dispatcher_t *dispatcher, uint32_t d)
{
    dispatcher->default_d = d;
}

void dispatcher_set_default_mbar(dispatcher_t *dispatcher, bool mbar)
{
    dispatcher->default_mbar = mbar;
}

void dispatcher_set_default_n_max(dispatcher_t *dispatcher, uint32_t n_max)
{
    dispatcher->default_n_max = n_max;
}

/* Dispatcher's worker methods */

bool dispatcher_has_idle_worker(dispatcher_t *dispatcher)
{
    uint32_t i;
    for (i = 0; i < MAX_WORKERS; i++)
    {
        if (worker_is_idle(&dispatcher->workers[i]))
        {
            return true;
        }
    }
    return false;
}

bool dispatcher_has_busy_worker(dispatcher_t *dispatcher)
{
    uint32_t i;
    for (i = 0; i < MAX_WORKERS; i++)
    {
        if (worker_is_busy(&dispatcher->workers[i]))
        {
            return true;
        }
    }
    return false;
}

bool dispatcher_has_finished_worker(dispatcher_t *dispatcher)
{
    uint32_t i;
    for (i = 0; i < MAX_WORKERS; i++)
    {
        if (worker_is_finished(&dispatcher->workers[i]))
        {
            return true;
        }
    }
    return false;
}

worker_t *dispatcher_get_idle_worker(dispatcher_t *dispatcher)
{
    uint32_t i;
    for (i = 0; i < MAX_WORKERS; i++)
    {
        if (worker_is_idle(&dispatcher->workers[i]))
        {
            return &dispatcher->workers[i];
        }
    }
    return NULL;
}

worker_t *dispatcher_get_finished_worker(dispatcher_t *dispatcher, bool blocking)
{
    uint32_t i;
    worker_t *worker;
    bool has_working;

    for (i = 0; i < MAX_WORKERS; i++)
    {
        worker = &dispatcher->workers[i];
        if (worker_is_finished(worker))
        {
            return worker;
        }
        if (worker_is_busy(worker))
        {
            has_working = true;
        }
    }
    /* If non-blocking, then return NULL */
    if (!blocking) return NULL;
    /* If all workers are IDLE, then there will never be a finished worker */
    if (!has_working) return NULL;

    while (true)
    {
        nanosleep(&kSleepTimeMicroSeconds, NULL);
        for (i = 0; i < MAX_WORKERS; i++)
        {
            worker = &dispatcher->workers[i];
            if (worker_is_finished(worker))
            {
                return worker;
            }
        }
    }
    return NULL;
}

void dispatcher_kill_all(dispatcher_t *dispatcher)
{
    uint32_t i;
    worker_t *worker;

    for (i = 0; i < MAX_WORKERS; i++)
    {
        worker = &dispatcher->workers[i];
        if (worker_is_alive(worker))
        {
            worker_kill(worker);
        }
    }
}

/*
 *  Worker methods.
 */

static void worker_init(worker_t *worker, dispatcher_t *dispatcher, uint32_t row, uint32_t col)
{
    /* These variables must be set before calling any worker_* functions.. */
    worker->param_count = 0;
    worker->dispatcher = dispatcher;
    worker->dev_row = row;
    worker->dev_col = col;

    worker_set_state(worker, WORKER_IDLE);
    worker_set_param_count(worker, 0);
    worker_set_to_default(worker);
}

void worker_start(worker_t *worker)
{
    worker_state_t status;
    die_if_dead(worker, __func__);
    die_if_busy(worker, __func__);
    worker_set_state(worker, WORKER_READY);

    worker_get_state(worker, &status);
    while (status != WORKER_WORKING || status != WORKER_DONE)
    {
        nanosleep(&kSleepTimeMicroSeconds, NULL);
        worker_get_state(worker, &status);
    }
}

void worker_wait(worker_t *worker)
{
    if (worker_is_working(worker))
    {
        nanosleep(&kSleepTimeMicroSeconds, NULL);
    }
}

void worker_reset(worker_t *worker)
{
    die_if_busy(worker, __func__);
    die_if_dead(worker, __func__);
    worker_set_to_default(worker);
    worker_set_param_count(worker, 0);

    if (worker_is_finished(worker))
    {
        worker_set_state(worker, WORKER_IDLE);
    }
}

static void worker_kill(worker_t * worker)
{
    if (!worker_is_alive(worker)) return;
    if (!worker_is_dying(worker))
    {
        worker_set_state(worker, WORKER_DIE);
        while (worker_is_alive(worker))
        {
            nanosleep(&kSleepTimeMicroSeconds, NULL);
        }
    }
}

/* Worker's setters and getters */

static void worker_set_data(worker_t *worker, uint32_t addr, void *data, uint32_t data_size)
{
    e_write(
        &worker->dispatcher->dev, worker->dev_row, worker->dev_col,
        addr, data, data_size);
}

static void worker_get_data(worker_t *worker, uint32_t addr, void *data, uint32_t data_size)
{
    e_read(
        &worker->dispatcher->dev, worker->dev_row, worker->dev_col,
        addr, data, data_size);
}

static void worker_set_uint32(worker_t *worker, uint32_t addr, uint32_t value)
{
    worker_set_data(worker, addr, &value, sizeof(uint32_t));
}

static void worker_get_uint32(worker_t *worker, uint32_t addr, uint32_t *value)
{
    worker_get_data(worker, addr, value, sizeof(uint32_t));
}

static void worker_set_state(worker_t *worker, worker_state_t state)
{
    worker_set_data(worker, STATE_ADDR, &state, sizeof(worker_state_t));
}

static void worker_get_state(worker_t *worker, worker_state_t *state)
{
    worker_get_data(worker, STATE_ADDR, state, sizeof(worker_state_t));
}

static void worker_set_param_count(worker_t *worker, uint32_t count)
{
    worker->param_count = count;
    worker_set_uint32(worker, PARAM_COUNT_ADDR, count);
}

void worker_set_give_parameters(worker_t *worker, parameter_set_t *set)
{
    uint32_t count, i;
    real_t r_vec[MAX_BATCH_SIZE];
    real_t i_vec[MAX_BATCH_SIZE];
    parameter_t *p;
    die_if_busy(worker, __func__);

    count = worker->dispatcher->batch_size;
    if (count > set->n)
    {
        count = set->n;
    }

    if (count > 0)
    {
        for (i = 0; i < count; i++)
        {
            p = &set->parameters[set->n - i - 1];
            r_vec[i] = p->c.real;
            i_vec[i] = p->c.img;
            worker->points[i].x = p->x;
            worker->points[i].y = p->y;
        }
    }
    parameter_set_clear_n(set, count);

    /* Write parameters to worker vector. */
    worker_set_data(worker, R_VEC_ADDR, r_vec, count * sizeof(real_t));
    worker_set_data(worker, I_VEC_ADDR, i_vec, count * sizeof(real_t));
    worker_set_param_count(worker, count);
}

void worker_set_take_parameters(worker_t *worker, parameter_set_t *set)
{
    uint32_t i;
    real_t r_vec[MAX_BATCH_SIZE];
    real_t i_vec[MAX_BATCH_SIZE];
    uint32_t out_vec[MAX_BATCH_SIZE];
    parameter_t p;
    die_if_busy(worker, __func__);

    if (worker->param_count == 0)
    {
        return;
    }

    /* Get data + results from core.  */
    worker_get_data(worker, R_VEC_ADDR, r_vec, worker->param_count * sizeof(real_t));
    worker_get_data(worker, I_VEC_ADDR, i_vec, worker->param_count * sizeof(real_t));
    worker_get_data(worker, OUT_VEC_ADDR, out_vec, worker->param_count * sizeof(uint32_t));

    for (i = 0; i < worker->param_count; i++)
    {
        p.x = worker->points[i].x;
        p.y = worker->points[i].y;
        p.c.real = r_vec[i];
        p.c.img = i_vec[i];
        p.out = out_vec[i];
        parameter_set_push(set, &p);
    }

    worker_set_param_count(worker, 0);
}

void worker_get_d(worker_t *worker, uint32_t *d)
{
    worker_get_uint32(worker, D_ADDR, d);
}
void worker_set_d(worker_t *worker, uint32_t d)
{
    die_if_busy(worker, __func__);
    worker_set_uint32(worker, D_ADDR, d);
}

void worker_get_mbar(worker_t *worker, bool *mbar)
{
    worker_get_data(worker, MBAR_ADDR, mbar, sizeof(bool));
}

void worker_set_mbar(worker_t *worker, bool mbar)
{
    die_if_busy(worker, __func__);
    worker_set_data(worker, MBAR_ADDR, &mbar, sizeof(bool));
}

void worker_get_n_max(worker_t *worker, uint32_t *n_max)
{
    worker_get_uint32(worker, N_MAX_ADDR, n_max);
}

void worker_set_n_max(worker_t *worker, uint32_t n_max)
{
    die_if_busy(worker, __func__);
    worker_set_uint32(worker, N_MAX_ADDR, n_max);
}

static void worker_set_to_default(worker_t * worker)
{
    worker_set_d(worker, worker->dispatcher->default_d);
    worker_set_mbar(worker, worker->dispatcher->default_mbar);
    worker_set_n_max(worker, worker->dispatcher->default_n_max);
    worker_set_param_count(worker, 0);
}

/* State checkers */

static bool worker_is_alive(worker_t *worker)
{
    worker_state_t state;
    worker_get_state(worker, &state);
    return state != WORKER_WAKING && state != WORKER_DEAD;
}

bool worker_is_idle(worker_t *worker)
{
    worker_state_t state;
    worker_get_state(worker, &state);
    return state == WORKER_IDLE;
}

bool worker_is_busy(worker_t *worker)
{
    worker_state_t state;
    worker_get_state(worker, &state);
    return state == WORKER_READY || state == WORKER_WORKING;
}

static bool worker_is_working(worker_t *worker)
{
    worker_state_t state;
    worker_get_state(worker, &state);
    return state == WORKER_WORKING;
}

bool worker_is_finished(worker_t *worker)
{
    worker_state_t state;
    worker_get_state(worker, &state);
    return state == WORKER_DONE;
}

static bool worker_is_dying(worker_t *worker)
{
    worker_state_t state;
    worker_get_state(worker, &state);
    return state == WORKER_DIE;
}
