/*
 * Mandelbrot Parallella E-Core Worker
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "e_worker.h"
#include "mandelbrot.h"

/*
 * Shared-Memory Pointers
 */
static volatile worker_state_t * const state_ptr = (worker_state_t *) STATE_ADDR;
/* Batch-wide parameters. */
static volatile uint32_t const * const d_ptr = (uint32_t *) D_ADDR;
static volatile uint32_t const * const mbar_ptr = (uint32_t *) MBAR_ADDR;
static volatile uint32_t const * const n_max_ptr = (uint32_t *) N_MAX_ADDR;
static volatile uint32_t * const batch_size_ptr = (uint32_t *) PARAM_COUNT_ADDR;
/* Input/output parameters. */
static volatile uint32_t * const out_vec = (uint32_t *) OUT_VEC_ADDR;
static volatile real_t * const r_vec = (real_t *) R_VEC_ADDR;
static volatile real_t * const i_vec = (real_t *) I_VEC_ADDR;

/*
 *  Shared Memory - Setters and Getters.
 */

static void set_state(worker_state_t state)
{
    *state_ptr = state;
}

static void get_state(worker_state_t *state)
{
    *state = *state_ptr;
}

static void get_base_parameters(uint32_t *d, bool *mbar, uint32_t *n_max, uint32_t *batch_size)
{
    *d = *d_ptr;
    *mbar = *mbar_ptr;
    *n_max = *n_max_ptr;
    *batch_size = *batch_size_ptr;
}

static void get_vec_parameters(uint32_t i, complex_t *c)
{
    c->real = r_vec[i];
    c->img = i_vec[i];
}
static void set_vec_result(uint32_t i, uint32_t out)
{
    out_vec[i] = out;
}

static void wait_for_job(worker_state_t *state)
{
    do
    {
        get_state(state);
    }
    while (*state == WORKER_IDLE);
}

static void wait_for_reset(worker_state_t *state)
{
    do
    {
        get_state(state);
    }
    while (*state == WORKER_DONE);
}

/*
 *  Worker Main
 */
int main(void)
{
    worker_state_t state;
    uint32_t batch_size, d, n_max, out, i;
    complex_t c;
    bool mbar;
    set_state(WORKER_IDLE);
    while (true)
    {
        wait_for_job(&state);
        if (state == WORKER_DIE) break;
        /* Fractal calculation. */
        get_base_parameters(&d, &mbar, &n_max, &batch_size);
        for (i = 0; i < batch_size; i++)
        {
            get_vec_parameters(i, &c);
            fractal_divergence(&c, d, mbar, n_max, &out);
            set_vec_result(i, out);
        }
        /* Signal done. */
        set_state(WORKER_DONE);
        wait_for_reset(&state);
        if (state == WORKER_DIE) break;
        set_state(WORKER_IDLE);
    }
    set_state(WORKER_DEAD);
    return EXIT_SUCCESS;
}
