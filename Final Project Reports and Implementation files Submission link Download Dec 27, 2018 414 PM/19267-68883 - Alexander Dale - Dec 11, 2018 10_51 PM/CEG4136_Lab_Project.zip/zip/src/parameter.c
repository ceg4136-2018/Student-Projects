/*
 * Mandelbrot Parameters and Results
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "parameter.h"

static uint32_t const kSizeStep = 128;

void create_parameter_set(uint32_t size, parameter_set_t *set)
{
    memset(set, 0, sizeof(parameter_set_t));
    if (size == 0)
    {
        return;
    }

    set->parameters = (parameter_t*)malloc(size * sizeof(parameter_t));
    if (!set->parameters)
    {
        fprintf(stderr, "Failed to allocate parameter set of size %u\n", size);
    }
    set->size = size;
}

void release_parameter_set(parameter_set_t *set)
{
    memset(set->parameters, 0, set->size * sizeof(parameter_t));
    free(set->parameters);
    memset(set, 0, sizeof(parameter_set_t));
}

static void copy_parameter(parameter_t *dest, parameter_t const *src)
{
    memcpy(dest, src, sizeof(parameter_t));
}

static void swap_parameters(parameter_t *a, parameter_t *b)
{
    parameter_t temp;
    if (a == b) return;
    copy_parameter(&temp, a);
    copy_parameter(a, b);
    copy_parameter(b, &temp);
}

static void resize_set(parameter_set_t *set, uint32_t new_size)
{
    parameter_t *parameters;
    uint32_t i;

    if (set->size == new_size) return;
    parameters = (parameter_t *)malloc(new_size * sizeof(parameter_t));
    if (!parameters)
    {
        fprintf(stderr, "Failed to resize parameter set from %u to %u\n", set->size, new_size);
        exit(EXIT_FAILURE);
    }

    if (set->n < new_size)
    {
        for (i = 0; i < set->n; i++)
        {
            copy_parameter(&parameters[i], &set->parameters[i]);
        }
    }
    else
    {
        for (i = 0; i < new_size; i++)
        {
            copy_parameter(&parameters[i], &set->parameters[i]);
        }
        set->n = new_size;
    }

    if (set->parameters)
    {
        free(set->parameters);
    }
    set->parameters = parameters;
    set->size = new_size;
}

static void check_and_resize(parameter_set_t *set, uint32_t count)
{
    if ((set->n + count) > set->size)
    {
        resize_set(set, set->size + kSizeStep);
        if (count > kSizeStep)
        {
            check_and_resize(set, count);
        }
    }
}

static void check_index(parameter_set_t const *set, uint32_t index)
{
    if (index >= set->n)
    {
        fprintf(stderr, "Parameter index out of bounds: idx = %u, n = %u\n", index, set->n);
        exit(EXIT_FAILURE);
    }
}

void parameter_set_push(parameter_set_t *set, parameter_t const *parameter)
{
    check_and_resize(set, 1);
    copy_parameter(&set->parameters[set->n], parameter);
    set->n++;
}

void parameter_set_pop(parameter_set_t *set, parameter_t *parameter)
{
    if (set->n == 0)
    {
        fprintf(stderr, "Cannot pop from empty parameter set!\n");
        exit(EXIT_FAILURE);
    }
    copy_parameter(parameter, &set->parameters[set->n-1]);
    set->n--;
}

void parameter_set_get(parameter_set_t const *set, uint32_t index, parameter_t *parameter)
{
    check_index(set, index);
    copy_parameter(parameter, &set->parameters[index]);
}

void parameter_set_set(parameter_set_t *set, uint32_t index, parameter_t const *parameter)
{
    check_index(set, index);
    copy_parameter(&set->parameters[index], parameter);
}

bool parameter_set_is_empty(parameter_set_t const *set)
{
    return set->n == 0;
}

void parameter_set_clear(parameter_set_t *set)
{
    set->n = 0;
}

void parameter_set_clear_n(parameter_set_t *set, uint32_t count)
{
    if (count > set->n)
    {
        count = set->n;
    }
    set->n -= count;
}

void parameter_set_transfer(parameter_set_t *dest, parameter_set_t *src, uint32_t count)
{
    uint32_t i;

    if (count == 0) return;

    if (count > src->n)
    {
        parameter_set_transfer(dest, src, src->n);
        return;
    }

    check_and_resize(dest, count);
    src->n -= count;
    for (i = 0; i < count; i++)
    {
        copy_parameter(&dest->parameters[dest->n + i], &src->parameters[src->n + i]);
    }
    dest->n += count;
}

void parameter_set_transfer_all(parameter_set_t *dest, parameter_set_t *src)
{
    parameter_set_transfer(dest, src, src->n);
}

void parameter_set_shuffle(parameter_set_t *set)
{
    uint32_t i, s;
    for (i = 0; i < set->n; i++)
    {
        s = rand() % set->n;
        swap_parameters(&set->parameters[i], &set->parameters[s]);
    }
}
