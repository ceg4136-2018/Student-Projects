/*
 * Image and PNG Includes
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#ifndef _IMAGE_H_
#define _IMAGE_H_

#include "common.h"

typedef struct {
    uint8_t red;
    uint8_t green;
    uint8_t blue;
} rgb_color_t;

typedef struct {
    uint32_t width;
    uint32_t height;
    uint32_t *counts;
    rgb_color_t *colors;
} image_t;

void create_image(uint32_t width, uint32_t height, image_t *image);
void release_image(image_t *image);

void image_set_count(image_t *image, uint32_t x, uint32_t y, uint32_t count);
void image_set_color(image_t *image, uint32_t x, uint32_t y, rgb_color_t const *color);

uint32_t image_get_count(image_t const *image, uint32_t x, uint32_t y);
void image_get_color(image_t const *image, uint32_t x, uint32_t y, rgb_color_t *color);

#ifndef _NO_PNG
/* Exports an image to the PNG file specified. */
void export_image_to_png(image_t const *image, char const *filename);
#endif /* _NO_PNG */

#endif /* _IMAGE_H_ */
