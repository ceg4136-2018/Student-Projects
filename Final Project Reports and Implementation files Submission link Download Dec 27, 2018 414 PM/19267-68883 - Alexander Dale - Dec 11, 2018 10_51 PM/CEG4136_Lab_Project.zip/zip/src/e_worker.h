/*
 * Mandelbrot Parallella E-Core Worker Header
 *
 *  Copyright (c) 2018 Alex Dale
 *  See LICENSE for details
 */
#ifndef _E_WORKER_H_
#define _E_WORKER_H_

#include "common.h"

typedef enum {
    WORKER_WAKING = 0,
    WORKER_IDLE,
    WORKER_READY,
    WORKER_WORKING,
    WORKER_DONE,
    WORKER_RESET,
    WORKER_DIE,
    WORKER_DEAD
} worker_state_t;

#define D_ADDR              0x2000
#define MBAR_ADDR           (D_ADDR + sizeof(bool))
#define N_MAX_ADDR          (MBAR_ADDR + sizeof(uint32_t))

#define STATE_ADDR          (N_MAX_ADDR + sizeof(uint32_t))
#define PARAM_COUNT_ADDR    (STATE_ADDR + sizeof(worker_state_t))

#define OUT_VEC_ADDR    0x2800
#define R_VEC_ADDR      0x3000
#define I_VEC_ADDR      0x4000

#endif /* _E_WORKER_H_ */
