# CEG 4136 - Parallella Mandelbrot Generator

Project code for generating a Mandelbrot fractal using the Parallella
board's multi-core architecture.

There are two versions of the Mandelbrot Generator
1.  POXIS `pthread` - Using threads for parallelization (default)
2.  Parallella eCore - Using eCores for parallelization

## Building

To generate fractal PNGs you will need to install `libpng`.

On Ubuntu: `sudo apt-get install libpng`

On Arch: `sudo pacman -S libpng`

To build:

```bash
make pthread
make parallella  # Only if you have the Parallella toolchain.
```

If you cannot install `libpng` for whatever reason, you can build without
PNG capabilities using:

```bash
make pthread-no-png
make parallella-no-png
```

## Usage

For help, run:

```base
$ bin/main.exe --help
```
