#!/bin/bash

set -e


cd Debug

./rpsProject.elf

