#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "e_lib.h"
#include <time.h>
#include <errno.h>
#include <unistd.h>

int main(void) {
	//unsigned int *seed;
	const char		  ShmName[] = "rps_shm"; 
	const char        Msg[] = "the winner is %d";
	char              buf[256] = { 0 };
	e_coreid_t		  coreid;
	e_memseg_t   	  emem;
	unsigned          my_row;
	unsigned          my_col;
	//seed = (unsigned *) 0x7000;

  int r1 = 33;
  int r2 =33;
  int p1 = 33;
  int p2 = 33;
  int s1 = 33;
  int s2 = 33;
  int seed = 1234;

  coreid = e_get_coreid();
  seed = coreid;
 
  int rollVal1, rollVal2;
  srand(seed);

  int roll1 = rand() % (r1 + p1 + s1);
  rollVal1 = rollType(roll1, r1, p1, s1);
  srand(seed*seed);
  int roll2 = rand() % (r2 + p2 + s2);
  rollVal2 = rollType(roll2, r2, p2, s2);
  
  //printf(winner(rollVal1, rollVal2));

	coreid = e_get_coreid();
	e_coords_from_coreid(coreid, &my_row, &my_col);

	if ( E_OK != e_shm_attach(&emem, ShmName) ) {
		return EXIT_FAILURE;
	}

	// Attach to the shm segment
	//char MSG2[]= "winner is " + winner(rollVal1, rollVal2)
	//snprintf(buf, sizeof(buf),Msg , seed);
	snprintf(buf, sizeof(buf),Msg ,winner(rollVal1,rollVal2));

	if ( emem.size >= strlen(buf) + 1 ) {
		// Write the message (including the null terminating
		// character) to shared memory
		e_write((void*)&emem, buf, my_row, my_col, NULL, strlen(buf) + 1);
	} else {
		// Shared memory region is too small for the message
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;

}


	//converts the result of the the d100 roll into a choice of rock, paper of scissors
int rollType(int roll, int r, int p, int s){
  if(roll<=r){
    return 0;
  }
  else if(roll<= (r + p)){
    return 1;
  }
  else{
    return 2;
  }
}
 //gets the winner from the two inputted players
  int winner(int pick1, int pick2){
  if(pick1==pick2){
    return 0;
  }
  else if(pick1==0 && pick2 == 2){
    return 1;
  }
  else if(pick1==0 && pick2 == 1){
    return 2;
  }
  else if(pick1==1 && pick2 == 0){
    return 1;
  }
  else if(pick1==1 && pick2 == 2){
    return 2;
  }
  else if(pick1==2 && pick2 ==0){
    return 2;
  }
  else if(pick1==2 && pick2 == 1){
    return 1;
  }
  else{
    return 0;
  }
}


