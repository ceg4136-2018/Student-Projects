/*Made by Oleg Lukyanenko 8330816 and Michael Cook 8314747 for 
CEG4136 Computer Architecture 3.

Parts of this code were taken from examples of epiphany-examples from adaptera.
Parts used to initialize cores, and some necesseay variables were copied. 
All other parts of the code, just as the logic and message passing was coded by us
*/





#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <e-hal.h>

const unsigned ShmSize = 128;
const char ShmName[] = "rps_shm"; 
const unsigned SeqLen = 20;

int main(int argc, char *argv[])
{
	unsigned row, col, coreid, i,j,cycles;
	e_platform_t platform;
	e_epiphany_t dev;
	e_memseg_t  emem; 
	e_mem_t   mbuf;
	int rc;
	int seed = time(NULL);

	srand(1);

	e_set_loader_verbosity(H_D0);
	e_set_host_verbosity(H_D0);

	// initialize system, read platform params from
	// default HDF. Then, reset the platform and
	// get the actual system parameters.
	e_init(NULL);
	e_reset_system();
	e_get_platform_info(&platform);

	// Allocate a buffer in shared external memory
	// for message passing from eCore to host.
	rc = e_shm_alloc(&mbuf, ShmName, ShmSize);
	if (rc != E_OK)
		rc = e_shm_attach(&mbuf, ShmName);

	if (rc != E_OK) {
		fprintf(stderr, "Failed to allocate shared memory. Error is %s\n",
				strerror(errno));
		return EXIT_FAILURE;
	}

for (cycles=0; cycles<100;cycles++){
	for (i=0; i<4; i++)
	{
		for (j=0; j<4; j++)
		{
			/* was removed after trying to write a unique seed to each core
		for (i=0; i<platform.rows; i++){
    		for (j=0; j<platform.cols;j++){
      		e_write(&dev, i, j, 0x7000, &seed, sizeof(seed));

    		}
		}
		*/
		char buf[ShmSize];

		row = i;
		col = j;
		coreid = (row + platform.row) * 64 + col + platform.col;
		printf("%3d: eCore 0x%03x (%2d,%2d) ran a game and ", i, coreid, row, col);

		// Open the single-core workgroup and reset the core, in
		// case a previous process is running. Note that we used
		// core coordinates relative to the workgroup.
		e_open(&dev, row, col, 1, 1);
		e_reset_group(&dev);
		
	

		// Load the device program onto the selected eCore
		// and launch after loading.
		if ( E_OK != e_load("e_rpsProject.elf", &dev, 0, 0, E_TRUE) ) {
			fprintf(stderr, "Failed to load e_rpsProject.elf\n");
			return EXIT_FAILURE;
		}

		// Wait for core program execution to finish, then
		// read message from shared buffer.
		usleep(10000);

		e_read(&mbuf, 0, 0, 0, buf, ShmSize);

		// Print the message and close the workgroup.
		printf("\"%s\"\n", buf);
		e_close(&dev);
	}
}
}

	// Release the allocated buffer and finalize the
	// e-platform connection.
	e_shm_release(ShmName);
	e_finalize();

	return 0;
}

