#define TEST_MODE

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

#define GAME_ITERATIONS 100
#define DEAD  'O'
#define ALIVE 'X'

unsigned i, j, ncells, row, col;
unsigned game_iteration = GAME_ITERATIONS;

unsigned rows=4;
unsigned cols=4;

void check_cell(char *result);

int main(int argc, char * argv[]) {
  clock_t t;
  t = clock();
  
  // Arguments handling
  switch(argc) {
    case 4:
        game_iteration = atoi(argv[1]);
        rows = atoi(argv[2]);
        cols = atoi(argv[3]);
    case 1: break;
    default:
      printf("Wrong number of arguments\nUsage: ./main.elf [nb iterations] [nb rows] [nb cols]\n");
      return 0;
  }

  ncells = rows * cols;
  char result[ncells];
  
  for(i = 0; i < ncells; i++){
    result[i] = DEAD;
  }  
  
  for(i = 0; i < game_iteration; i++){
    for(row = 0; row < rows; row++){
      for(col = 0; col < cols; col++){
        check_cell(result);
      }
    }
#ifdef TEST_MODE
    if(i!=0) //Only print once when testing
      continue;
#endif
    for(j = 0; j < cols+2; j++){
      fprintf(stdout, "X  ");
    }
    fprintf(stdout, "\n");
    for(row = 0; row < rows; row++) {
      fprintf(stdout, "X  ");
      for(col = 0; col < cols; col++) {
        fprintf(stdout, "%c  ", result[row*cols + col]);
      }
      fprintf(stdout, "X  ");
      fprintf(stdout, "\n");
    } 
    for(j = 0; j < cols+2; j++){
      fprintf(stdout, "X  ");
    }
    fprintf(stdout, "\n");
    fprintf(stdout, "\n");
    fflush(stdout);
  
  }
#ifdef TEST_MODE
  t = clock() - t;
  double time_taken = ((double)t)/CLOCKS_PER_SEC;
  time_taken = time_taken * 1000;
  fprintf(stdout, "Execution time: %f miliseconds\n", time_taken);
#endif
  return 0;
}


void check_cell(char *result) {

  unsigned core_num;
  char neighbor_status;
  
  //Calculate current index  
  core_num = row * cols + col;

  unsigned alive_neighbor;
    
    alive_neighbor = 0;
    // top left
    if(row == 0 && col == 0) {
      alive_neighbor += 5; // dead anyway!
    }
    // top right
    else if(row == 0 && col == cols-1) {
      alive_neighbor += 5; // dead anyway!
    }
    // bottom left
    else if(row == rows-1 && col == 0) {
      alive_neighbor += 5; // dead anyway!
    }
    // bottom right
    else if(row == rows-1 && col == cols-1) {
      alive_neighbor += 5; // dead anyway!
    }
    // top
    else if(row == 0) {
      alive_neighbor += 3;
      neighbor_status = result[core_num-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
    }
    // bottom
    else if(row == rows-1) {
      alive_neighbor += 3;
      neighbor_status = result[core_num-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num - cols-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num - cols];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num - cols+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
    }
    // left
    else if(col == 0) {
      alive_neighbor += 3;
      neighbor_status = result[core_num - cols];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num - cols+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
    }
    // right
    else if(col == cols-1) {
      alive_neighbor += 3;
      neighbor_status = result[core_num - cols];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num - cols-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
    }
    // middle
    else {
      neighbor_status = result[core_num - cols-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols-1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num - cols];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num - cols+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
      neighbor_status = result[core_num + cols+1];
      if(neighbor_status == ALIVE) alive_neighbor++;
    }
    if(alive_neighbor == 3) result[core_num] = ALIVE;
    else if(alive_neighbor < 2) result[core_num] = DEAD;
    else if(alive_neighbor > 3) result[core_num] = DEAD;

}
