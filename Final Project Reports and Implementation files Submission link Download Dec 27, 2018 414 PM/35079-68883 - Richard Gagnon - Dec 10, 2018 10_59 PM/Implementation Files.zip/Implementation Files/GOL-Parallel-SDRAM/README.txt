Game of Life (Parallel with SDRAM accessing)

This implementation of Conway's Game of Life runs in parallel with a configurable number of cores and a configurable board size.
To run this program follow the instructions below:

Step 1: Move the folder onto the Parallella board.

Step 2: Enter the following command: ./build.sh
  This will compile the program. Only required first time running

Step 3: Enter the following command: ./main.elf [# iterations] [# cores] [# rows] [# cols]
  Replace [# iterations] with your desired number of iterations (This must be a whole non negative number).
  Replace [# cores] with your desired number of cores.
    Since workgroups on Parallella must be rectangular in shape only the following values will work correctly:
    1, 2, 3, 4, 6, 8, 9, 12, 16 cores
  Replace [# rows] with your desired number of rows for the board (This must be a whole non negative number).
  Replace [# cols] with your desired number of columns for the board (This must be a whole non negative number).
  Note: Program will not execute unless you enter all required fields.

NOTE: There is a test mode implemented in this program. By default it is on. To run in test mode uncomment the first line of the file 'main.c' : '#define TEST_MODE'
      To run in normal mode simply comment the line.
	  
	  In test mode the board will only get printed once and the execution time of the program will be measured. 
