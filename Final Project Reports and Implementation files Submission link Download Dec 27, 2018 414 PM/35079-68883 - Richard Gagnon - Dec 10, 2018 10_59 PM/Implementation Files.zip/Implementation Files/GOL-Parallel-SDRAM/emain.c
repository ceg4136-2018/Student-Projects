/*
 * Author: Noémien Kocher
 * Date: january 2016
 * Licence: MIT
 * Purpose:
 *   This file is run by each eCore, it represents the life of a cell. Until it
 *   is stopped, loops over and check its neighbor so as to update its status.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

#include <e-lib.h> // Epiphany cores library

#define READY 0x1
#define DEAD  '0'
#define ALIVE 'X'
/*
 * [1] status, O = dead X = alive
 * [0] ready, 0 = not 1 = ready
 */
volatile char *result;

volatile uint32_t *status;
volatile uint32_t *state;
volatile uint32_t *readMem;
unsigned nCellsResponsible = 0;
unsigned ncores, nrows, ncols, ncells;

/*void writeResult(unsigned core_num, int i){
  result  = (volatile char *) (0x8f000000 + (2*ncores + 2)*sizeof(uint32_t) + 0x1*i);
  *result = swap[i];
}*/

int main(void) {

  unsigned core_row, core_col,
           group_rows, group_cols,
           core_num, top_neighbor_row,
          top_neighbor_col, bot_neighbor_row,
          bot_neighbor_col;
  char neighbor_status, swap;
  uint32_t iterations = 0;
  uint32_t iof = 0; // Sticky Integer Overflow Flag

  core_row = e_group_config.core_row;
  core_col = e_group_config.core_col;
  group_rows = e_group_config.group_rows;
  group_cols = e_group_config.group_cols;

  core_num = core_row * group_cols + core_col;
  ncores = group_cols * group_rows;

  // initialize cells DEAD

  //Determine coordinates of top neighbor and bottom neighbor
 /* e_neighbor_id(E_NEXT_CORE, E_GROUP_WRAP, &bot_neighbor_row, &bot_neighbor_col);
  e_neighbor_id(E_PREV_CORE, E_GROUP_WRAP, &top_neighbor_row, &top_neighbor_col);
*/


  // start at begining of sdram
  status = (volatile uint32_t*) (0x8f000000 + 0x4*core_num);
  // we add offset of 0x10 = 4cores  * sizeof(uint32_t)
  state = (volatile uint32_t*) (0x8f000000 + 0x4*ncores + 0x4*core_num);

  readMem = (volatile uint32_t*) (0x8f000000 + 0x1*2*ncores*sizeof(uint32_t));
  nrows = *readMem;

  readMem = (volatile uint32_t*) (0x8f000000 + 0x1*2*ncores*sizeof(uint32_t) + 0x1*sizeof(uint32_t));
  ncols = *readMem;

  ncells = nrows*ncols;
  if(ncells%ncores == 0) nCellsResponsible = ncells/ncores;
  else if(core_num >= ncells%ncores) nCellsResponsible = ncells/ncores;
  else nCellsResponsible = ncells/ncores + 1;

  
  result = (volatile char *) (0x8f000000 + (2*ncores + 2)*sizeof(uint32_t));
  
  for(int i = core_num; i<ncells; i+=ncores){
    *(result+i) = DEAD;
  }

  unsigned alive_neighbor;
  while(1) {
    iterations++; // increment number of iteration
    unsigned tmp_iof = e_reg_read(E_REG_STATUS);
    tmp_iof = tmp_iof & (4096); // use the sticky overflow integer flag
    iof = iof | tmp_iof;

    for(int i = core_num; i < ncells; i=i+ncores){
      alive_neighbor = 0;
      result = (volatile char *) (0x8f000000 + (2*ncores + 2)*sizeof(uint32_t) + 0x1*i);
      

      if(i == 0) alive_neighbor += 5; //Top left corner
      else if(i == ncols-1) alive_neighbor += 5; //Top right corner
      else if(i == ncells-ncols) alive_neighbor += 5; //Bot left corner
      else if(i == ncells-1) alive_neighbor += 5; //Bot right corner
      //Top
      else if(i < ncols){
          alive_neighbor += 3;
         
          neighbor_status = *(result - 1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + 1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols-1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols-1);
          if(neighbor_status == ALIVE) alive_neighbor++;	  
      }
      //Bottom
      else if(i > ncells-ncols){
          alive_neighbor += 3;

          neighbor_status = *(result - 1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + 1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - ncols-1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - ncols);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - ncols-1);
          if(neighbor_status == ALIVE) alive_neighbor++;	  
      }
      //Left
      else if(i%ncols == 0){
          alive_neighbor += 3;

          neighbor_status = *(result - ncols);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - ncols+1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols+1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + 1);
          if(neighbor_status == ALIVE) alive_neighbor++;	  
      }
      //Right
      else if(i%ncols == ncols-1){
          alive_neighbor += 3;

          neighbor_status = *(result - ncols);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - ncols-1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols-1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - 1);
          if(neighbor_status == ALIVE) alive_neighbor++;	  
      }
      // middle rows
      else{
          neighbor_status = *(result - ncols-1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - ncols);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - ncols+1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + 1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result - 1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols-1);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols);
          if(neighbor_status == ALIVE) alive_neighbor++;
          neighbor_status = *(result + ncols+1);
          if(neighbor_status == ALIVE) alive_neighbor++;   	  
      }

    if(alive_neighbor == 3) swap = ALIVE;
    else if(alive_neighbor < 2) swap = DEAD;
    else if(alive_neighbor > 3) swap = DEAD;
    *result = swap;
    //writeResult(core_num, i); // store result
    }
    *status = iterations; // store number of iterations so far
    *state = iof;
  }
}
