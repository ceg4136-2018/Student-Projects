#define TEST_MODE

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

#include <e-hal.h>  // Epiphany Hardware Abstraction Layer
                    // functionality for communicating with epiphany chip when
                    // the application runs on a host, typically the ARM µp

#define BUFOFFSET (0x01000000)  // SDRAM is at 0x8f00'0000,
                                // offset in e_read starts at 0x8e00'0000
#define GAME_ITERATIONS 100

unsigned i, j, ncores, row, col;
unsigned game_iteration = GAME_ITERATIONS;
unsigned workgroup_cols = 4;
unsigned workgroup_rows = 4;
unsigned rows = 16;
unsigned cols = 16;

/*
 * Init the epiphany platform
 */
void init_epiphany(e_platform_t * platform) {
  e_init(NULL);
  e_reset_system();
  e_get_platform_info(platform);
}

/*
 * Create the workgroup and load programs into it
 */
init_workgroup(e_epiphany_t * dev) {
  e_return_stat_t result;
  e_open(dev, 0, 0, workgroup_rows, workgroup_cols); // Create an epiphany cores workgroup
  e_reset_group(dev);
  // load programs into cores workgroup, do not execute it immediately
  result = e_load_group("emain16.elf", dev, 0, 0, workgroup_rows, workgroup_cols, E_TRUE);
  if(result != E_OK) {
    printf("Error Loading the Epiphany Application %i\n", result);
  }
  e_start_group(dev);
}

/*
 * Main entry
 */
int main(int argc, char * argv[]) {

  // Arguments handling
  switch(argc) {
    case 2: game_iteration = atoi(argv[1]);
    case 1: break;
    default:
      printf("Wrong number of arguments\nUsage: ./main.elf [nb iterations]\n");
      return 0;
  }

  e_platform_t platform;  // platform infos
  e_epiphany_t dev;       // provides access to cores workgroup
  e_mem_t emem;           // shared memory buffer

  init_epiphany(&platform);

  ncores = workgroup_rows * workgroup_cols;
  char result[rows*cols];     // to store the results, size of cores
  // allocate a space to share data between e_cores and here
  // offset starts from 0x8e00'0000
  // sdram (shared space) is at 0x8f00'0000
  // so 0x8e00'0000 + 0x0100'0000 = 0x8f00'0000
  e_alloc(&emem, BUFOFFSET, ncores*sizeof(uint32_t) +
                            ncores*sizeof(uint32_t) +
			    rows*cols*sizeof(char));

  init_workgroup(&dev);

  clock_t t;
  t = clock();

  int countComplete;
  uint32_t iterations[ncores*2];
  // we read from the allocated space and store it to the result array
  for(i = 0; i < game_iteration; i++) {
    usleep(1000);
    e_read(&emem, 0, 0, 0x4*ncores*2, &result, rows*cols * sizeof(char)); // reads what's ben put in buffer
    for(col = 0; col < cols+2; col++){
      fprintf(stdout, "X  ");
    }
    fprintf(stdout, "\n");
    for(row = 0; row < rows; row++) {
      fprintf(stdout, "X  ");
      for(col = 0; col < cols; col++) {
        fprintf(stdout, "%c  ", result[row*cols+col]);
      }
      fprintf(stdout, "X");
      fprintf(stdout, "\n");
    }
    for(col = 0; col < cols+2; col++){
      fprintf(stdout, "X  ");
    }
    fprintf(stdout, "\n");
    fprintf(stdout, "\n");
    fflush(stdout);
 
#ifdef TEST_MODE
    while(1){ //Wait for all cores to complete required number of iterations
      e_read(&emem, 0, 0, 0x0, &iterations, ncores * sizeof(uint32_t) + ncores *sizeof(uint32_t));
      countComplete = 0; 
      for(i = 0; i < ncores; i++){
	 if(iterations[i] >= game_iteration){
	   countComplete++;
	 }
      }
      if(countComplete == ncores){
	break;
      } 
    }
    break;
#endif
 }

#ifdef TEST_MODE
  t = clock() - t; //stop timing and print
  double time_taken = (((double)t)/CLOCKS_PER_SEC)*1000;
  fprintf(stdout, "Execution time: %f miliseconds\n", time_taken); 
#endif
 
  // read iterations
  e_read(&emem, 0, 0, 0x0, &iterations, ncores * sizeof(uint32_t) + ncores * sizeof(uint32_t));
  for(i = 0; i < ncores; i++) {
    fprintf(stdout, "eCore %02i:\titeration %i,\tiof %i\n", i, iterations[i],iterations[ncores+i]);
  }
  e_close(&dev);

  return 0;
}
