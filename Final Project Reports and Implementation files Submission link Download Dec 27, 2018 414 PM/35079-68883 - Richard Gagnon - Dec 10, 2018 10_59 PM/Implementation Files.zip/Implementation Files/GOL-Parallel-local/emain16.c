/*
 * Author: Noémien Kocher
 * Date: january 2016
 * Licence: MIT
 * Purpose:
 *   This file is run by each eCore, it represents the life of a cell. Until it
 *   is stopped, loops over and check its neighbor so as to update its status.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

#include <e-lib.h> // Epiphany cores library

#define READY 0x1
#define DEAD  '0'
#define ALIVE 'X'
/*
 * [1] status, O = dead X = alive
 * [0] ready, 0 = not 1 = ready
 */
char swap[8] SECTION(".text_bank2");
volatile char *result;
volatile uint32_t *status;
volatile uint32_t *state;
unsigned nCellsResponsible = 16;
unsigned ncores;

void writeResult(unsigned core_num, int i){
  result  = (volatile char *) (0x8f000000 + 0x8*ncores + 0x1*nCellsResponsible*core_num + 0x1*i);
  *result = swap[i];
}

int main(void) {

  unsigned core_row, core_col,
           group_rows, group_cols,
           core_num, top_neighbor_row,
          top_neighbor_col, bot_neighbor_row,
          bot_neighbor_col;
  char neighbor_status;
  uint32_t iterations = 0;
  uint32_t iof = 0; // Sticky Integer Overflow Flag

  core_row = e_group_config.core_row;
  core_col = e_group_config.core_col;
  group_rows = e_group_config.group_rows;
  group_cols = e_group_config.group_cols;

  core_num = core_row * group_cols + core_col;
  ncores = group_cols * group_rows;

  // initialize cells DEAD
  for(int i = 0; i<nCellsResponsible; i++){
    swap[i] = DEAD;
  }

  //Determine coordinates of top neighbor and bottom neighbor
  e_neighbor_id(E_NEXT_CORE, E_GROUP_WRAP, &bot_neighbor_row, &bot_neighbor_col);
  e_neighbor_id(E_PREV_CORE, E_GROUP_WRAP, &top_neighbor_row, &top_neighbor_col);



  // start at begining of SDRAM
  status = (volatile uint32_t*) (0x8f000000 + 0x4*core_num);
  // we add offset of 0x20 = 8 cores * sizeof(uint32_t)
  state = (volatile uint32_t*) (0x8f000000 + 0x4*group_cols*group_rows + 0x4*core_num);

  unsigned alive_neighbor;
  while(1) {
    iterations++; // increment number of iteration
    unsigned tmp_iof = e_reg_read(E_REG_STATUS);
    tmp_iof = tmp_iof & (4096); // use the sticky overflow integer flag
    iof = iof | tmp_iof;

    for(int i = 0; i < nCellsResponsible; i++){
      alive_neighbor = 0;
      // top row
      if(core_num == 0){
        if(i == 0) alive_neighbor += 5; //Top left corner
        else if(i == nCellsResponsible-1) alive_neighbor += 5; //Top right corner
        else{
            alive_neighbor += 3;
            for(int y = 0; y < 5; y++){ //5 cells to check
              if(y == 0) neighbor_status = swap[i-1]; //check left
              else if(y == 1) neighbor_status = swap[i+1]; //check right
              else if(y == 2) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+0x1*(i-1)),1); //check bottom left
              else if(y == 3) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+0x1*i),1); // check bottom
              else if(y == 4) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+0x1*(i+1)),1); // check bottom right
              if(neighbor_status == ALIVE) alive_neighbor++;
            }
        }
      }
      // bottom row
      else if(core_num == group_cols*group_rows-1) {
        if(i == 0) alive_neighbor += 5; //Bottom left corner
        else if(i == nCellsResponsible-1) alive_neighbor += 5; //Bottom right corner
        else{
            alive_neighbor += 3;
            for(int y = 0; y < 5; y++){ //5 cells to check
              if(y == 0) neighbor_status = swap[i-1]; //check left
              else if(y == 1) neighbor_status = swap[i+1]; //check right
              else if(y == 2) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+0x1*(i-1)),1); //check top left
              else if(y == 3) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+0x1*i),1); // check top
              else if(y == 4) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+0x1*(i+1)),1); // check top right
              if(neighbor_status == ALIVE) alive_neighbor++;
            }
        }
      }
      // middle rows
      else{
        if(i == 0){ //left side
          alive_neighbor += 3;
          for(int y = 0; y < 5; y++){ //5 cells to check
            if(y == 0) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+i),1); //check top
            else if(y == 1) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+i),1); //check bottom
            else if(y == 2) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+i+1),1); //check top right
            else if(y == 3) neighbor_status = swap[i+1];  // check right
            else if(y == 4) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+i+1),1); // check bot right
            if(neighbor_status == ALIVE) alive_neighbor++;
          }
        }
        else if(i == nCellsResponsible-1){ //right side
          alive_neighbor += 3;
          for(int y = 0; y < 5; y++){ //5 cells to check
            if(y == 0) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+i),1); //check top
            else if(y == 1) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+i),1); //check bottom
            else if(y == 2) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+i-1),1); //check top left
            else if(y == 3) neighbor_status = swap[i-1];  // check left
            else if(y == 4) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+i-1),1); // check bot left
            if(neighbor_status == ALIVE) alive_neighbor++;
          }
        }
        else{ //middle
          for(int y = 0; y < 8; y++){ //8 cells to check
            if(y == 0) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+i),1); //check top
            else if(y == 1) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+i+1),1); //top right
            else if(y == 2) neighbor_status = swap[i+1]; //check right
            else if(y == 3) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+i+1),1);  // check bottom right
            else if(y == 4) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+i),1); // check bottom
            else if(y == 5) e_read(&e_group_config,&neighbor_status,bot_neighbor_row,bot_neighbor_col,(char*)(0x4000+i-1),1); //check bot left
            else if(y == 6) neighbor_status = swap[i-1];  // check left
            else if(y == 7) e_read(&e_group_config,&neighbor_status,top_neighbor_row,top_neighbor_col,(char*)(0x4000+i-1),1); // check top left
            if(neighbor_status == ALIVE) alive_neighbor++;
          }
        }
      }

    if(alive_neighbor == 3) swap[i] = ALIVE;
    else if(alive_neighbor < 2) swap[i] = DEAD;
    else if(alive_neighbor > 3) swap[i] = DEAD;
    writeResult(core_num, i); // store result
    }
    *status = iterations; // store number of iterations so far
    *state = iof;
  }
}
