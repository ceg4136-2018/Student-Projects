Game of Life (Parallel with local memory)

This implementation of Conway's Game of Life runs in parallel using eCores local memory for checking neighboring cells.
To run this program follow the instructions below:

Step 1: Move the folder onto the Parallella board.

Step 2: Enter the following command: ./build.sh
  This will compile the program. Only required first time running

Step 3: For 8 core implementation enter command: 	./main8.elf [# iterations]
		For 16 core implementation entter commaind: ./main16.elf [# iterations]
  Replace [# iterations] with your desired number of iterations (This must be a whole non negative number).
  Note: Program will not execute unless you enter all required fields.

NOTE: There is a test mode implemented in this program. By default it is on. To run in test mode uncomment the first line of the file 'main.c' : '#define TEST_MODE'
      To run in normal mode simply comment the line.
	  
	  In test mode the board will only get printed once and the execution time of the program will be measured. 
