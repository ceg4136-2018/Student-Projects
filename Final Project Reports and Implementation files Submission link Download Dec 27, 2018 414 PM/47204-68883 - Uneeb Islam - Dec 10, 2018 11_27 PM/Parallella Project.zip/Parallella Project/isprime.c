#include <math.h>

//This is the code run by each core when it calculates a prime
//Note: it's the same algorithm as the single core
int isprime(unsigned long number) {

  int i, flag, 

  flag = 1; //Assume prime
    for(i=2; i<number; i++) {

      if(number%i == 0) { //If not prime
        flag = 0;
        break;
      }
    }
	return flag;
}
