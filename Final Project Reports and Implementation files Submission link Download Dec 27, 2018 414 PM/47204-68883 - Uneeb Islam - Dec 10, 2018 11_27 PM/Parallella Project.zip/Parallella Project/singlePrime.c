#include <math.h>
#include <stdio.h>
#include <time.h>

int main() {
	int currNum, totalNum, totalPrime = 1, flag, i;

	printf("Enter the number you want to calculate primes until: ");
	scanf("%d", &totalNum);

	clock_t start, end; //Used for calculating time it takes
	double timeTaken;

	start = clock();//Start the clock

	for(currNum=3; currNum<=totalNum; currNum+=2) { //Need to start at 3 and then every odd number

		flag = 1; //Assume prime
		for(i=2; i<currNum; i++) {

			if(currNum%i == 0) { //If not prime
				flag = 0;
				break;
			}
		}
		if(flag == 1) {
			totalPrime++; //2 is already counted
		}
	}
	end = clock(); //End the clock
	timeTaken = ((double) (end - start)) / CLOCKS_PER_SEC; //Calculate total time

	printf("There were %d prime numbers and it took %f seconds\n", totalPrime, timeTaken);

	return 0;
}