Mahnoor Cheema 8283145
Albert Fung 8251802 

Amazo
Final Project for Computer Architecture III

To run this project:

Run interface.py with Python 3.6
Please make sure to have all the dependencies installed (numpy and tkinter). 

If you have any questions, please feel free to email at: mchee050@uottawa.ca

Thanks!