from prims_maze import generate_prims_maze_matrix
from tkinter import Tk, Label, Button, Entry, Frame, StringVar
from environment import Maze
import amazo
from threading import Timer


WALL = -1

INPUT_SIZE_STATE = "INPUT_SIZE_STATE"
SELECT_TARGET_STATE = "SELECT_TARGET_STATE"
TRAINING_STATE = "TRAINING_STATE"
SELECT_START_STATE = "SELECT_START_STATE"

COLOR_WALL = "black"
COLOR_SPACE = "white"
COLOR_TARGET = "red"
COLOR_START = "blue"
COLOR_PATH = "orange"


class AmazoUI:
    def __init__(self, master):
        # UI State
        self.state = INPUT_SIZE_STATE

        # Model
        self.size = None
        self.maze = None
        self.model = None

        # Frames
        master.title("Amazo")
        self.master = master
        self.input_size_frame = Frame(master)
        self.input_size_frame.grid(row=0, column=0, sticky='news')

        self.maze_frame = Frame(master)
        self.maze_frame.grid(row=0, column=0, sticky='news')

        self.create_input_size_frame()

    def create_input_size_frame(self):
        self.size_label = Label(self.input_size_frame, text="Size of maze (will be converted to an odd number)")
        self.size_label.pack()

        self.size_entry = Entry(self.input_size_frame)
        self.size_entry.pack()

        self.generate_button = Button(self.input_size_frame, text="Generate a maze!", command=self.generate)
        self.generate_button.pack()

        self.input_size_frame.tkraise()

    def create_maze_frame(self):
        self.maze_frame.tkraise()
        self.master.grid_rowconfigure(self.size, weight=1)
        self.master.grid_columnconfigure(self.size, weight=1)

        self.instruction = StringVar()
        self.instruction.set("Select a target location")
        self.instruction_label = Label(self.maze_frame, textvariable=self.instruction)
        self.instruction_label.grid(row=self.size, column=0, columnspan=self.size, sticky="new")

        self.error = StringVar()
        self.error_label = Label(self.maze_frame, textvariable=self.error)
        self.error_label.grid(row=self.size + 1, column=0, columnspan=self.size, sticky="new")

        self.restart_button = Button(self.maze_frame, text="Start over", command=self.reset)
        self.restart_button.grid(row=0, column=self.size + 1, columnspan=2, rowspan=2, sticky="new")

        self.code = StringVar()
        self.code.set("Solution Code:")
        self.code_label = Label(self.maze_frame, textvariable=self.code, bg="black", fg="white")
        self.code_label.grid(row=2, column=self.size + 1, columnspan=2, rowspan=self.size, sticky="new")

    def generate(self):
        try:
            self.size = (int(self.size_entry.get()) // 2) * 2 + 1
        except ValueError:
            print("Please enter a valid number")
            return None
        maze_matrix = generate_prims_maze_matrix(self.size, self.size)
        self.maze = Maze(maze_matrix)
        print(self.maze)
        self.tiles = []
        for row in range(self.size):
            tile_row = []
            for column in range(self.size):
                button = Button(self.maze_frame,
                                text="   ",
                                borderwidth=0,
                                bg=COLOR_WALL if maze_matrix[column, row] else COLOR_SPACE,
                                command=lambda row=row, column=column: self.click_tile(row, column))
                button.grid(row=row, column=column, sticky="new")
                tile_row.append(button)
            self.tiles.append(tile_row)
        # Update the state
        self.state = SELECT_TARGET_STATE
        self.create_maze_frame()

    def train_model(self):
        amazo.train_for_random_start(self.model, self.maze)
        self.state = SELECT_START_STATE
        self.error.set("")
        self.instruction.set("Please select a start location")
        print(amazo.get_navigation_map(self.model, self.maze))

    def click_tile(self, row, column):
        if self.state == SELECT_TARGET_STATE:
            self.select_target(row, column)
        elif self.state == SELECT_START_STATE:
            self.select_start(row, column)
        elif self.state == TRAINING_STATE:
            self.error.set("CANNOT SELECT START DURING TRAINING")
        else:
            self.error.set("Unexpected state: " + self.state)

    def select_target(self, row, column):
        if self.maze.content[column, row] == WALL:
            self.error.set("Must select an empty tile")
        else:
            self.state = TRAINING_STATE
            self.error.set("")
            self.tiles[row][column].configure(bg=COLOR_TARGET)
            self.instruction.set("Please wait while training occurs")

            self.maze.reset(target=(column, row))
            self.model = amazo.build_model(self.size)
            timer = Timer(1.0, self.train_model)
            timer.start()

    def select_start(self, row, column):
        if self.maze.content[column, row] == WALL:
            self.error.set("Must select an empty tile")
        else:
            self.error.set("")
            self.maze.reset()
            path = amazo.solve_for_position(self.model, self.maze, (column, row))
            code = amazo.path_to_code(path)
            code_block = "\n".join(code)
            print(code_block)
            self.code.set(code_block)
            self.show_path(path)

    def show_path(self, path):
        for row in range(self.size):
            for column in range(self.size):
                button = self.tiles[row][column]
                if (column, row) in path:
                    color = COLOR_PATH
                elif self.maze.content[column, row] == WALL:
                    color = COLOR_WALL
                else:
                    color = COLOR_SPACE
                button.config(bg=color)
        start = path[0]
        row, column = start
        button = self.tiles[column][row]
        button.config(bg=COLOR_START)
        target = path[-1]
        row, column = target
        button = self.tiles[column][row]
        button.config(bg=COLOR_TARGET)

    def reset(self):
        if self.state == TRAINING_STATE:
            self.error.set("Cannot reset during training")
        else:
            for widget in self.maze_frame.winfo_children():
                widget.destroy()
            self.state = INPUT_SIZE_STATE
            self.input_size_frame.tkraise()


if __name__ == "__main__":
    root = Tk()
    my_gui = AmazoUI(root)
    root.mainloop()
