The project report (4-page 2-column paper) is the Growing_RNN.pdf file.

The code/implementation is code.ipynb and needs to be opened with Jupyter Notebook and ran with python 3.
To run the code, make sure to install python3 and pip3 on your system then run:
pip3 install tensorflow keras

GROWING_RNN_RESULTS.xlsx is an Excel sheet that has all the results of the models trained, with all the scores (training and testing accuracy, precision, recall, training and testing time, loss, and much more).

Please let me know if you have any questions,

I can be reached at hqass076@uottawa.ca

Hamza
